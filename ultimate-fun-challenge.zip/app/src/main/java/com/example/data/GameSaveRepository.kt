package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Context.gameProgressDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "ultimate_fun_challenge_save")

interface GameSaveRepository {
  val progress: StateFlow<PlayerProgress>

  suspend fun ensureLoaded()

  suspend fun updateProgress(transform: (PlayerProgress) -> PlayerProgress)
}

class DataStoreGameSaveRepository(
  private val dataStore: DataStore<Preferences>,
  private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) : GameSaveRepository {

  constructor(context: Context) : this(context.applicationContext.gameProgressDataStore)

  private val _progress = MutableStateFlow(PlayerProgress())
  override val progress: StateFlow<PlayerProgress> = _progress.asStateFlow()

  private var loaded = false

  init {
    scope.launch { ensureLoaded() }
  }

  override suspend fun ensureLoaded() {
    if (loaded) return
    val prefs = dataStore.data.first()
    val raw = prefs[KEY_PLAYER_PROGRESS]
    if (!raw.isNullOrBlank()) {
      _progress.value = decodeProgress(raw)
    }
    loaded = true
  }

  override suspend fun updateProgress(transform: (PlayerProgress) -> PlayerProgress) {
    ensureLoaded()
    val updated = transform(_progress.value)
    _progress.value = updated
    dataStore.edit { prefs -> prefs[KEY_PLAYER_PROGRESS] = encodeProgress(updated) }
  }

  companion object {
    private val KEY_PLAYER_PROGRESS = stringPreferencesKey("player_progress_json_v1")

    fun encodeProgress(p: PlayerProgress): String {
      val root = JSONObject()
      root.put("coins", p.coins)
      root.put("highestUnlockedLevel", p.highestUnlockedLevel)
      root.put("endlessHighScore", p.endlessHighScore)
      root.put("brainBlitzHighScore", p.brainBlitzHighScore)
      root.put("totalHighScore", p.totalHighScore)
      root.put("selectedCharacterId", p.selectedCharacterId)
      root.put("selectedThemeId", p.selectedThemeId)
      root.put("sfxMuted", p.sfxMuted)
      root.put("bgmMuted", p.bgmMuted)
      root.put("dailyStreak", p.dailyStreak)
      root.put("lastDailyClaimEpochDay", p.lastDailyClaimEpochDay)
      root.put("totalAdsWatched", p.totalAdsWatched)
      root.put("totalRunsCompleted", p.totalRunsCompleted)

      val scoresObj = JSONObject()
      p.levelHighScores.forEach { (lvl, score) -> scoresObj.put(lvl.toString(), score) }
      root.put("levelHighScores", scoresObj)

      val starsObj = JSONObject()
      p.levelStars.forEach { (lvl, stars) -> starsObj.put(lvl.toString(), stars) }
      root.put("levelStars", starsObj)

      root.put("unlockedCharacterIds", JSONArray(p.unlockedCharacterIds.toList()))
      root.put("unlockedThemeIds", JSONArray(p.unlockedThemeIds.toList()))
      return root.toString()
    }

    fun decodeProgress(jsonString: String): PlayerProgress {
      return try {
        val root = JSONObject(jsonString)
        val scoresMap = mutableMapOf<Int, Int>()
        root.optJSONObject("levelHighScores")?.let { obj ->
          val keys = obj.keys()
          while (keys.hasNext()) {
            val k = keys.next()
            k.toIntOrNull()?.let { lvl -> scoresMap[lvl] = obj.optInt(k, 0) }
          }
        }
        val starsMap = mutableMapOf<Int, Int>()
        root.optJSONObject("levelStars")?.let { obj ->
          val keys = obj.keys()
          while (keys.hasNext()) {
            val k = keys.next()
            k.toIntOrNull()?.let { lvl -> starsMap[lvl] = obj.optInt(k, 0) }
          }
        }
        val chars = mutableSetOf("nova_bot")
        root.optJSONArray("unlockedCharacterIds")?.let { arr ->
          for (i in 0 until arr.length()) {
            arr.optString(i).takeIf { it.isNotBlank() }?.let { chars.add(it) }
          }
        }
        val themes = mutableSetOf("cyber_neon")
        root.optJSONArray("unlockedThemeIds")?.let { arr ->
          for (i in 0 until arr.length()) {
            arr.optString(i).takeIf { it.isNotBlank() }?.let { themes.add(it) }
          }
        }
        PlayerProgress(
          coins = root.optInt("coins", 120).coerceAtLeast(0),
          highestUnlockedLevel = root.optInt("highestUnlockedLevel", 1).coerceIn(1, 35),
          levelHighScores = scoresMap,
          levelStars = starsMap,
          endlessHighScore = root.optInt("endlessHighScore", 0),
          brainBlitzHighScore = root.optInt("brainBlitzHighScore", 0),
          totalHighScore = root.optInt("totalHighScore", 0),
          unlockedCharacterIds = chars,
          selectedCharacterId =
            root.optString("selectedCharacterId", "nova_bot").ifBlank { "nova_bot" },
          unlockedThemeIds = themes,
          selectedThemeId = root.optString("selectedThemeId", "cyber_neon").ifBlank { "cyber_neon" },
          sfxMuted = root.optBoolean("sfxMuted", false),
          bgmMuted = root.optBoolean("bgmMuted", false),
          dailyStreak = root.optInt("dailyStreak", 0),
          lastDailyClaimEpochDay = root.optLong("lastDailyClaimEpochDay", -1L),
          totalAdsWatched = root.optInt("totalAdsWatched", 0),
          totalRunsCompleted = root.optInt("totalRunsCompleted", 0),
        )
      } catch (_: Exception) {
        PlayerProgress()
      }
    }
  }
}

class InMemoryGameSaveRepository(initial: PlayerProgress = PlayerProgress()) : GameSaveRepository {
  private val _progress = MutableStateFlow(initial)
  override val progress: StateFlow<PlayerProgress> = _progress.asStateFlow()

  override suspend fun ensureLoaded() = Unit

  override suspend fun updateProgress(transform: (PlayerProgress) -> PlayerProgress) {
    _progress.value = transform(_progress.value)
  }
}
