package com.example.data

import androidx.compose.ui.graphics.Color

data class GameThemeSpec(
  val id: String,
  val name: String,
  val tagline: String,
  val cost: Int,
  val skyTop: Color,
  val skyBottom: Color,
  val trackSurface: Color,
  val gridLine: Color,
  val primaryAccent: Color,
  val secondaryAccent: Color,
)

data class RunnerCharacterSpec(
  val id: String,
  val name: String,
  val title: String,
  val cost: Int,
  val bodyColor: Color,
  val accentColor: Color,
  val trailColor: Color,
  val perkLabel: String,
  val bonusCoinChance: Float = 0f,
  val startingShield: Boolean = false,
)

data class LevelSpec(
  val levelNumber: Int,
  val worldIndex: Int,
  val worldName: String,
  val title: String,
  val targetDistance: Float,
  val baseSpeed: Float,
  val obstacleSpawnIntervalSec: Float,
  val brainGatesTarget: Int,
  val timedRushCoinGoal: Int,
  val timedRushSeconds: Int,
  val rewardCoins: Int,
  val star2Score: Int,
  val star3Score: Int,
  val puzzleDifficulty: Int,
  val hasSweeperBots: Boolean,
  val hasLaserWalls: Boolean,
)

data class DailyRewardDay(
  val day: Int,
  val coins: Int,
  val label: String,
)

data class PlayerProgress(
  val coins: Int = 120,
  val highestUnlockedLevel: Int = 1,
  val levelHighScores: Map<Int, Int> = emptyMap(),
  val levelStars: Map<Int, Int> = emptyMap(),
  val endlessHighScore: Int = 0,
  val brainBlitzHighScore: Int = 0,
  val totalHighScore: Int = 0,
  val unlockedCharacterIds: Set<String> = setOf("nova_bot"),
  val selectedCharacterId: String = "nova_bot",
  val unlockedThemeIds: Set<String> = setOf("cyber_neon"),
  val selectedThemeId: String = "cyber_neon",
  val sfxMuted: Boolean = false,
  val bgmMuted: Boolean = false,
  val dailyStreak: Int = 0,
  val lastDailyClaimEpochDay: Long = -1L,
  val totalAdsWatched: Int = 0,
  val totalRunsCompleted: Int = 0,
) {
  val totalStars: Int
    get() = levelStars.values.sum()

  fun canClaimDaily(currentEpochDay: Long): Boolean = lastDailyClaimEpochDay < currentEpochDay

  fun nextDailyRewardIndex(currentEpochDay: Long): Int {
    if (lastDailyClaimEpochDay < 0L) return 0
    val daysSince = currentEpochDay - lastDailyClaimEpochDay
    return if (daysSince > 1L) 0 else (dailyStreak % 7)
  }
}
