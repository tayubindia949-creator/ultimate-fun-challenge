package com.example.data

import androidx.compose.ui.graphics.Color
import kotlin.math.max

object GameCatalog {

  val themes: List<GameThemeSpec> =
    listOf(
      GameThemeSpec(
        id = "cyber_neon",
        name = "Cyber Neon",
        tagline = "Electric indigo & cyan grid",
        cost = 0,
        skyTop = Color(0xFF09071A),
        skyBottom = Color(0xFF1A1042),
        trackSurface = Color(0xFF100E2B),
        gridLine = Color(0xFF00E5FF),
        primaryAccent = Color(0xFF00E5FF),
        secondaryAccent = Color(0xFFFF2E93),
      ),
      GameThemeSpec(
        id = "synthwave_sunset",
        name = "Synthwave Dusk",
        tagline = "Crimson horizon & gold rails",
        cost = 180,
        skyTop = Color(0xFF1E0826),
        skyBottom = Color(0xFF4A1034),
        trackSurface = Color(0xFF210B22),
        gridLine = Color(0xFFFF7043),
        primaryAccent = Color(0xFFFFCA28),
        secondaryAccent = Color(0xFFFF4081),
      ),
      GameThemeSpec(
        id = "emerald_matrix",
        name = "Emerald Matrix",
        tagline = "Obsidian core & toxic lime pulse",
        cost = 320,
        skyTop = Color(0xFF041410),
        skyBottom = Color(0xFF0A2E23),
        trackSurface = Color(0xFF071C16),
        gridLine = Color(0xFF39FF88),
        primaryAccent = Color(0xFF39FF88),
        secondaryAccent = Color(0xFF00E5FF),
      ),
      GameThemeSpec(
        id = "cosmic_aurora",
        name = "Cosmic Aurora",
        tagline = "Royal violet & starlight prism",
        cost = 500,
        skyTop = Color(0xFF0D0624),
        skyBottom = Color(0xFF261254),
        trackSurface = Color(0xFF150B38),
        gridLine = Color(0xFFB388FF),
        primaryAccent = Color(0xFFE040FB),
        secondaryAccent = Color(0xFF64FFDA),
      ),
    )

  val characters: List<RunnerCharacterSpec> =
    listOf(
      RunnerCharacterSpec(
        id = "nova_bot",
        name = "Nova Bot",
        title = "Cyber Sprinter",
        cost = 0,
        bodyColor = Color(0xFF00E5FF),
        accentColor = Color(0xFFFFFFFF),
        trailColor = Color(0xFF00B8D4),
        perkLabel = "Balanced Arcade Core",
      ),
      RunnerCharacterSpec(
        id = "blaze_fox",
        name = "Blaze Fox",
        title = "Solar Dasher",
        cost = 150,
        bodyColor = Color(0xFFFF6D00),
        accentColor = Color(0xFFFFEA00),
        trailColor = Color(0xFFFF3D00),
        perkLabel = "+15% Bonus Coin Magnet Spark",
        bonusCoinChance = 0.15f,
      ),
      RunnerCharacterSpec(
        id = "volt_ninja",
        name = "Volt Ninja",
        title = "Shadow Circuit",
        cost = 280,
        bodyColor = Color(0xFF39FF88),
        accentColor = Color(0xFF0B2E1E),
        trailColor = Color(0xFF00E676),
        perkLabel = "Starts with Energy Shield",
        startingShield = true,
      ),
      RunnerCharacterSpec(
        id = "astro_cat",
        name = "Astro Cat",
        title = "Starlight Pilot",
        cost = 420,
        bodyColor = Color(0xFFE040FB),
        accentColor = Color(0xFF80D8FF),
        trailColor = Color(0xFFAA00FF),
        perkLabel = "+25% Bonus Coin Chance",
        bonusCoinChance = 0.25f,
      ),
      RunnerCharacterSpec(
        id = "omega_dragon",
        name = "Omega Wyrm",
        title = "Mythic Champion",
        cost = 700,
        bodyColor = Color(0xFFFFCA28),
        accentColor = Color(0xFFFF1744),
        trailColor = Color(0xFFFF9100),
        perkLabel = "Starter Shield + 30% Bonus Coins",
        bonusCoinChance = 0.30f,
        startingShield = true,
      ),
    )

  val dailyRewards: List<DailyRewardDay> =
    listOf(
      DailyRewardDay(1, 50, "Day 1"),
      DailyRewardDay(2, 75, "Day 2"),
      DailyRewardDay(3, 100, "Day 3"),
      DailyRewardDay(4, 150, "Day 4"),
      DailyRewardDay(5, 200, "Day 5"),
      DailyRewardDay(6, 300, "Day 6"),
      DailyRewardDay(7, 500, "Mega Day 7"),
    )

  private val worldNames =
    listOf(
      "Neon Genesis",
      "Cyber Canyon",
      "Pulse Matrix",
      "Quantum Rift",
      "Hypernova Finale",
    )

  private val levelTitles =
    listOf(
      "First Spark",
      "Coin Surge",
      "Sky Hurdles",
      "Twin Rails",
      "Gatekeeper",
      "Laser Drift",
      "Genesis Boss Run",
      "Canyon Dash",
      "Drone Alley",
      "Blitz Reflex",
      "Turbo Ridge",
      "Prism Rush",
      "Sweeper Storm",
      "Canyon Core",
      "Matrix Entry",
      "Binary Beat",
      "Synapse Sprint",
      "Volt Corridor",
      "Neon Labyrinth",
      "Hyper Switch",
      "Matrix Apex",
      "Rift Awakening",
      "Gravity Flip",
      "Quantum Leap",
      "Starlight Warp",
      "Logic Gauntlet",
      "Overdrive",
      "Rift Sovereign",
      "Solar Flare",
      "Nova Vortex",
      "Apex Reflex",
      "Omega Trial",
      "Velocity Zero",
      "Cosmic Ascent",
      "Ultimate Challenge",
    )

  val levels: List<LevelSpec> =
    (1..35).map { level ->
      val worldIndex = (level - 1) / 7
      val worldName = worldNames[worldIndex]
      val title = levelTitles[level - 1]
      val targetDistance = 520f + (level - 1) * 75f
      val baseSpeed = 340f + (level - 1) * 13.5f
      val spawnInterval = max(0.46f, 1.08f - (level - 1) * 0.017f)
      val brainGatesTarget =
        when {
          level <= 4 -> 1
          level <= 16 -> 2
          else -> 3
        }
      val rushGoal = 5 + (level / 4)
      val rushSeconds = max(9, 14 - (level / 8))
      val rewardCoins = 25 + level * 6
      val star2Score = (targetDistance * 1.6f).toInt() + level * 45
      val star3Score = (targetDistance * 2.35f).toInt() + level * 80
      val puzzleDifficulty =
        when {
          level <= 7 -> 1
          level <= 15 -> 2
          level <= 24 -> 3
          else -> 4
        }
      LevelSpec(
        levelNumber = level,
        worldIndex = worldIndex,
        worldName = worldName,
        title = title,
        targetDistance = targetDistance,
        baseSpeed = baseSpeed,
        obstacleSpawnIntervalSec = spawnInterval,
        brainGatesTarget = brainGatesTarget,
        timedRushCoinGoal = rushGoal,
        timedRushSeconds = rushSeconds,
        rewardCoins = rewardCoins,
        star2Score = star2Score,
        star3Score = star3Score,
        puzzleDifficulty = puzzleDifficulty,
        hasSweeperBots = level >= 6,
        hasLaserWalls = level >= 3,
      )
    }

  fun getTheme(id: String): GameThemeSpec = themes.firstOrNull { it.id == id } ?: themes.first()

  fun getCharacter(id: String): RunnerCharacterSpec =
    characters.firstOrNull { it.id == id } ?: characters.first()

  fun getLevel(levelNumber: Int): LevelSpec =
    levels.firstOrNull { it.levelNumber == levelNumber } ?: levels.first()
}
