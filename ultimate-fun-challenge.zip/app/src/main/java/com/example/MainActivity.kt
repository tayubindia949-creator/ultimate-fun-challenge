package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.UnityAdsManager
import com.example.audio.ArcadeSoundEngine
import com.example.data.DataStoreGameSaveRepository
import com.example.ui.UltimateFunChallengeApp

class MainActivity : ComponentActivity() {
  private val soundEngine by lazy { ArcadeSoundEngine() }
  private val adController by lazy { UnityAdsManager() }
  private val saveRepository by lazy { DataStoreGameSaveRepository(applicationContext) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    adController.initialize(applicationContext)

    setContent {
      val vm: MainViewModel =
        viewModel(
          factory =
            MainViewModelFactory(
              saveRepository = saveRepository,
              adController = adController,
              soundEngine = soundEngine,
            )
        )
      UltimateFunChallengeApp(viewModel = vm)
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    soundEngine.release()
  }
}
