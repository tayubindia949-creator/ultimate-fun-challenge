package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class SoundEffect {
  COIN,
  GEM,
  JUMP,
  LANE_SWAP,
  POWER_UP,
  HIT,
  BRAIN_CORRECT,
  BRAIN_WRONG,
  LEVEL_COMPLETE,
  GAME_OVER,
  TAP,
}

/**
 * Pure Kotlin PCM synthesized arcade audio engine (zero external media asset dependencies).
 * Safely degrades if AudioTrack is unavailable in headless JVM test environments.
 */
class ArcadeSoundEngine {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private var bgmJob: Job? = null
  private var bgmTrack: AudioTrack? = null

  @Volatile var sfxMuted: Boolean = false
  @Volatile var bgmMuted: Boolean = false
    set(value) {
      field = value
      if (value) stopBgm() else if (isAppForeground) startBgm()
    }

  @Volatile private var isAppForeground: Boolean = true

  fun playSfx(effect: SoundEffect) {
    if (sfxMuted) return
    scope.launch {
      try {
        val pcm = synthesizeSfx(effect)
        playStaticPcm(pcm, sampleRate = 22050)
      } catch (_: Throwable) {
        // Ignore audio hardware failures (e.g., Robolectric headless JVM)
      }
    }
  }

  fun onAppResume() {
    isAppForeground = true
    if (!bgmMuted) {
      startBgm()
    }
  }

  fun onAppPause() {
    isAppForeground = false
    stopBgm()
  }

  fun release() {
    stopBgm()
  }

  @Synchronized
  fun startBgm() {
    if (bgmMuted || !isAppForeground) return
    if (bgmJob?.isActive == true) return

    bgmJob =
      scope.launch {
        val sampleRate = 22050
        val loopSamples = buildSynthwaveLoop(sampleRate)
        val byteLen = loopSamples.size * 2
        val minBuf =
          try {
            AudioTrack.getMinBufferSize(
              sampleRate,
              AudioFormat.CHANNEL_OUT_MONO,
              AudioFormat.ENCODING_PCM_16BIT,
            )
          } catch (_: Throwable) {
            -1
          }
        if (minBuf <= 0) return@launch

        val track =
          try {
            AudioTrack.Builder()
              .setAudioAttributes(
                AudioAttributes.Builder()
                  .setUsage(AudioAttributes.USAGE_GAME)
                  .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                  .build()
              )
              .setAudioFormat(
                AudioFormat.Builder()
                  .setSampleRate(sampleRate)
                  .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                  .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                  .build()
              )
              .setBufferSizeInBytes(maxOf(minBuf, sampleRate))
              .setTransferMode(AudioTrack.MODE_STREAM)
              .build()
          } catch (_: Throwable) {
            null
          } ?: return@launch

        bgmTrack = track
        try {
          track.play()
          val chunkSize = 2048
          var offset = 0
          while (isActive && !bgmMuted && isAppForeground) {
            val count = minOf(chunkSize, loopSamples.size - offset)
            track.write(loopSamples, offset, count)
            offset += count
            if (offset >= loopSamples.size) offset = 0
            delay(10)
          }
        } catch (_: Throwable) {
          // AudioTrack stream ended or unavailable
        } finally {
          try {
            track.stop()
            track.release()
          } catch (_: Throwable) {}
          if (bgmTrack === track) bgmTrack = null
        }
      }
  }

  @Synchronized
  fun stopBgm() {
    bgmJob?.cancel()
    bgmJob = null
    bgmTrack?.let { track ->
      try {
        track.pause()
        track.flush()
        track.release()
      } catch (_: Throwable) {}
    }
    bgmTrack = null
  }

  private fun playStaticPcm(samples: ShortArray, sampleRate: Int) {
    val track =
      AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(samples.size * 2)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()

    track.write(samples, 0, samples.size)
    track.play()
    scope.launch {
      delay((samples.size * 1000L / sampleRate) + 80L)
      try {
        track.stop()
        track.release()
      } catch (_: Throwable) {}
    }
  }

  private fun synthesizeSfx(effect: SoundEffect): ShortArray {
    val sr = 22050
    return when (effect) {
      SoundEffect.COIN -> toneSequence(sr, listOf(987.77 to 0.055, 1318.51 to 0.09), 0.32f)
      SoundEffect.GEM ->
        toneSequence(sr, listOf(1046.5 to 0.05, 1318.5 to 0.05, 1567.98 to 0.11), 0.35f)
      SoundEffect.JUMP -> sweep(sr, 260.0, 680.0, 0.13, 0.32f)
      SoundEffect.LANE_SWAP -> sweep(sr, 420.0, 560.0, 0.06, 0.2f)
      SoundEffect.POWER_UP ->
        toneSequence(sr, listOf(523.25 to 0.06, 659.25 to 0.06, 783.99 to 0.06, 1046.5 to 0.12), 0.34f)
      SoundEffect.HIT -> sweep(sr, 240.0, 75.0, 0.22, 0.45f)
      SoundEffect.BRAIN_CORRECT ->
        toneSequence(sr, listOf(587.33 to 0.07, 739.99 to 0.07, 880.0 to 0.08, 1174.66 to 0.14), 0.35f)
      SoundEffect.BRAIN_WRONG -> toneSequence(sr, listOf(311.13 to 0.12, 233.08 to 0.18), 0.35f)
      SoundEffect.LEVEL_COMPLETE ->
        toneSequence(
          sr,
          listOf(523.25 to 0.08, 659.25 to 0.08, 783.99 to 0.08, 1046.5 to 0.14, 1318.51 to 0.22),
          0.38f,
        )
      SoundEffect.GAME_OVER ->
        toneSequence(sr, listOf(392.0 to 0.14, 349.23 to 0.14, 311.13 to 0.16, 261.63 to 0.26), 0.35f)
      SoundEffect.TAP -> sweep(sr, 640.0, 720.0, 0.035, 0.16f)
    }
  }

  private fun sweep(
    sampleRate: Int,
    startHz: Double,
    endHz: Double,
    durationSec: Double,
    volume: Float,
  ): ShortArray {
    val count = (sampleRate * durationSec).toInt().coerceAtLeast(1)
    val out = ShortArray(count)
    var phase = 0.0
    for (i in 0 until count) {
      val t = i.toDouble() / count
      val freq = startHz + (endHz - startHz) * t
      phase += 2.0 * PI * freq / sampleRate
      val env = (1.0 - t) * volume
      out[i] = (sin(phase) * env * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
    }
    return out
  }

  private fun toneSequence(
    sampleRate: Int,
    notes: List<Pair<Double, Double>>,
    volume: Float,
  ): ShortArray {
    val totalSamples = notes.sumOf { (sampleRate * it.second).toInt() }.coerceAtLeast(1)
    val out = ShortArray(totalSamples)
    var index = 0
    for ((freq, dur) in notes) {
      val n = (sampleRate * dur).toInt()
      for (i in 0 until n) {
        if (index >= totalSamples) break
        val t = i.toDouble() / n
        val env = exp(-t * 2.5) * volume
        val sample = (sin(2.0 * PI * freq * i / sampleRate) * env * Short.MAX_VALUE).toInt()
        out[index++] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
      }
    }
    return out
  }

  private fun buildSynthwaveLoop(sampleRate: Int): ShortArray {
    // 16-step uplifting 128 BPM arcade synthwave bass + arpeggio loop (~3.75 seconds)
    val stepDur = 0.234
    val stepSamples = (sampleRate * stepDur).toInt()
    val bassNotes =
      doubleArrayOf(
        130.81, 130.81, 164.81, 196.0,
        146.83, 146.83, 174.61, 220.0,
        164.81, 164.81, 196.0, 246.94,
        146.83, 164.81, 196.0, 261.63,
      )
    val arpNotes =
      doubleArrayOf(
        523.25, 659.25, 783.99, 659.25,
        587.33, 698.46, 880.0, 698.46,
        659.25, 783.99, 987.77, 783.99,
        587.33, 659.25, 783.99, 1046.50,
      )
    val out = ShortArray(stepSamples * bassNotes.size)
    for (step in bassNotes.indices) {
      val bassFreq = bassNotes[step]
      val arpFreq = arpNotes[step]
      val baseIdx = step * stepSamples
      for (i in 0 until stepSamples) {
        val t = i.toDouble() / stepSamples
        val env = exp(-t * 3.0)
        val bass = sin(2.0 * PI * bassFreq * i / sampleRate) * 0.11
        val arp = sin(2.0 * PI * arpFreq * i / sampleRate) * 0.06 * env
        val value = ((bass + arp) * Short.MAX_VALUE).toInt()
        out[baseIdx + i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
      }
    }
    return out
  }
}
