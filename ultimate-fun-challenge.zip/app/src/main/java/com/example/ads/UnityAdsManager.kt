package com.example.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.unity3d.ads.AdExpiredListener
import com.unity3d.ads.InitializationConfiguration
import com.unity3d.ads.InitializationListener
import com.unity3d.ads.LoadConfiguration
import com.unity3d.ads.LoadListener
import com.unity3d.ads.RewardedAd
import com.unity3d.ads.RewardedShowListener
import com.unity3d.ads.ShowConfiguration
import com.unity3d.ads.ShowFinishState
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsError
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Represents the lifecycle state of the Unity Ads SDK and rewarded placement. */
enum class RewardedAdStatus {
  UNINITIALIZED,
  INITIALIZING,
  INIT_FAILED,
  LOADING,
  READY,
  LOAD_FAILED,
  SHOWING,
}

data class RewardedAdUiState(
  val status: RewardedAdStatus = RewardedAdStatus.UNINITIALIZED,
  val isSdkInitialized: Boolean = false,
  val statusMessage: String = "Preparing Unity Ads...",
  val lastErrorMessage: String? = null,
  val lastRewardEventId: String? = null,
)

/** Abstraction for rewarded ad lifecycle so production UnityAds and JVM/Robolectric tests share exact callback logic. */
interface RewardedAdController {
  val uiState: StateFlow<RewardedAdUiState>

  fun initialize(context: Context)

  fun loadRewardedAd()

  fun showRewardedAd(
    activity: Activity,
    onRewardVerified: (coinsAwarded: Int) -> Unit,
    onAdNotRewarded: (reason: String) -> Unit,
  )

  fun retry()
}

/** Callbacks forwarded from Unity Ads RewardedAd show lifecycle. */
interface RewardedShowCallbacks {
  fun onStarted()

  fun onClicked()

  fun onRewarded()

  fun onCompleted(state: ShowFinishState)

  fun onFailed(code: Int?, message: String)
}

/** Handle representing a loaded Unity RewardedAd instance. */
interface LoadedRewardedAd {
  fun setOnExpired(onExpired: () -> Unit)

  fun show(activity: Activity, configuration: ShowConfiguration, callbacks: RewardedShowCallbacks)
}

interface RewardedLoadCallback {
  fun onLoaded(ad: LoadedRewardedAd)

  fun onLoadFailed(code: Int?, message: String)
}

/** Thin wrapper over Unity Ads 4.21.0 non-deprecated SDK methods. */
interface UnityAdsSdkBridge {
  fun isInitialized(): Boolean

  fun initialize(config: InitializationConfiguration, onComplete: (errorCode: Int?, errorMessage: String?) -> Unit)

  fun load(configuration: LoadConfiguration, callback: RewardedLoadCallback)
}

/**
 * Production Unity Ads SDK 4.21.0 integration using the non-deprecated
 * InitializationConfiguration + RewardedAd + RewardedShowListener API,
 * with strict anti-duplicate and verified-completion reward delivery guarantees.
 */
class UnityAdsManager(
  private val sdkBridge: UnityAdsSdkBridge = RealUnityAdsSdkBridge(),
  private val connectivityChecker: (Context) -> Boolean = ::defaultIsNetworkAvailable,
) : RewardedAdController {

  private val _uiState = MutableStateFlow(RewardedAdUiState())
  override val uiState: StateFlow<RewardedAdUiState> = _uiState.asStateFlow()

  private var appContext: Context? = null
  private var loadedRewardedAd: LoadedRewardedAd? = null

  // Guards against duplicate reward delivery for a single show session
  // (e.g., if both onRewarded and onCompleted(COMPLETED) fire).
  private var activeShowToken: String? = null
  private var rewardDeliveredForActiveShow: Boolean = false
  private var pendingRewardCallback: ((Int) -> Unit)? = null
  private var pendingNoRewardCallback: ((String) -> Unit)? = null

  private val initCompleteCallback: (Int?, String?) -> Unit = { errorCode, errorMessage ->
    if (errorCode == null && errorMessage == null) {
      _uiState.value =
        _uiState.value.copy(
          isSdkInitialized = true,
          status = RewardedAdStatus.LOADING,
          statusMessage = "Unity Ads initialized. Loading rewarded video...",
          lastErrorMessage = null,
        )
      loadRewardedAd()
    } else {
      val errorDesc = "Code ${errorCode ?: -1}: ${errorMessage ?: "Initialization failed"}"
      _uiState.value =
        _uiState.value.copy(
          isSdkInitialized = false,
          status = RewardedAdStatus.INIT_FAILED,
          statusMessage = "Ads unavailable right now. Your progress is safe.",
          lastErrorMessage = errorDesc,
        )
    }
  }

  private val loadCallback =
    object : RewardedLoadCallback {
      override fun onLoaded(ad: LoadedRewardedAd) {
        loadedRewardedAd = ad
        ad.setOnExpired {
          if (loadedRewardedAd === ad && _uiState.value.status == RewardedAdStatus.READY) {
            loadedRewardedAd = null
            loadRewardedAd()
          }
        }
        _uiState.value =
          _uiState.value.copy(
            status = RewardedAdStatus.READY,
            statusMessage = "Rewarded video ready (+${UnityAdsConfig.REWARDED_COINS_AMOUNT} Coins)",
            lastErrorMessage = null,
          )
      }

      override fun onLoadFailed(code: Int?, message: String) {
        loadedRewardedAd = null
        val reason = "Code ${code ?: -1}: $message"
        _uiState.value =
          _uiState.value.copy(
            status = RewardedAdStatus.LOAD_FAILED,
            statusMessage = "No rewarded video available right now. Tap Retry to try again.",
            lastErrorMessage = reason,
          )
      }
    }

  private val showCallbacks =
    object : RewardedShowCallbacks {
      override fun onStarted() {
        // Never grant rewards when an ad starts.
        _uiState.value =
          _uiState.value.copy(
            status = RewardedAdStatus.SHOWING,
            statusMessage = "Playing rewarded video...",
          )
      }

      override fun onClicked() {
        // Clicking an ad does not grant a reward.
      }

      override fun onRewarded() {
        deliverVerifiedRewardIfEligible()
      }

      override fun onCompleted(state: ShowFinishState) {
        if (state == ShowFinishState.COMPLETED) {
          deliverVerifiedRewardIfEligible()
        } else {
          finishWithoutReward("Video was skipped. Watch the full ad to earn coins.")
        }
        loadedRewardedAd = null
        loadRewardedAd()
      }

      override fun onFailed(code: Int?, message: String) {
        val reason = "Code ${code ?: -1}: $message"
        val noRewardCallback = pendingNoRewardCallback
        activeShowToken = null
        rewardDeliveredForActiveShow = false
        pendingRewardCallback = null
        pendingNoRewardCallback = null
        loadedRewardedAd = null

        _uiState.value =
          _uiState.value.copy(
            status = RewardedAdStatus.LOAD_FAILED,
            statusMessage = "Ad playback failed. Your saved progress is untouched.",
            lastErrorMessage = reason,
          )
        noRewardCallback?.invoke(reason)
        loadRewardedAd()
      }
    }

  private fun deliverVerifiedRewardIfEligible() {
    val currentToken = activeShowToken ?: return
    if (rewardDeliveredForActiveShow) return

    rewardDeliveredForActiveShow = true
    val rewardCallback = pendingRewardCallback
    activeShowToken = null
    pendingRewardCallback = null
    pendingNoRewardCallback = null

    _uiState.value =
      _uiState.value.copy(
        status = RewardedAdStatus.LOADING,
        statusMessage = "Reward earned! +${UnityAdsConfig.REWARDED_COINS_AMOUNT} Coins added.",
        lastErrorMessage = null,
        lastRewardEventId = currentToken,
      )
    rewardCallback?.invoke(UnityAdsConfig.REWARDED_COINS_AMOUNT)
  }

  private fun finishWithoutReward(reason: String) {
    if (rewardDeliveredForActiveShow) return
    val noRewardCallback = pendingNoRewardCallback
    activeShowToken = null
    pendingRewardCallback = null
    pendingNoRewardCallback = null

    _uiState.value =
      _uiState.value.copy(
        status = RewardedAdStatus.LOADING,
        statusMessage = reason,
        lastErrorMessage = reason,
      )
    noRewardCallback?.invoke(reason)
  }

  override fun initialize(context: Context) {
    val applicationContext = context.applicationContext
    appContext = applicationContext

    if (sdkBridge.isInitialized() || _uiState.value.isSdkInitialized) {
      _uiState.value = _uiState.value.copy(isSdkInitialized = true)
      if (_uiState.value.status == RewardedAdStatus.UNINITIALIZED ||
        _uiState.value.status == RewardedAdStatus.INIT_FAILED
      ) {
        loadRewardedAd()
      }
      return
    }

    if (!connectivityChecker(applicationContext)) {
      _uiState.value =
        _uiState.value.copy(
          isSdkInitialized = false,
          status = RewardedAdStatus.INIT_FAILED,
          statusMessage = "Offline mode: Ads require an internet connection. Game remains playable!",
          lastErrorMessage = "No internet connection",
        )
      return
    }

    _uiState.value =
      _uiState.value.copy(
        status = RewardedAdStatus.INITIALIZING,
        statusMessage = "Connecting to Unity Ads (Test Mode)...",
        lastErrorMessage = null,
      )

    try {
      val config =
        InitializationConfiguration.Builder(UnityAdsConfig.GAME_ID)
          .withTestMode(UnityAdsConfig.TEST_MODE)
          .build()
      sdkBridge.initialize(config = config, onComplete = initCompleteCallback)
    } catch (t: Throwable) {
      _uiState.value =
        _uiState.value.copy(
          isSdkInitialized = false,
          status = RewardedAdStatus.INIT_FAILED,
          statusMessage = "Unity Ads unavailable. Game remains fully playable.",
          lastErrorMessage = t.message ?: "Initialization exception",
        )
    }
  }

  override fun loadRewardedAd() {
    val ctx = appContext
    if (!sdkBridge.isInitialized() && !_uiState.value.isSdkInitialized) {
      if (ctx != null) {
        initialize(ctx)
      }
      return
    }

    if (ctx != null && !connectivityChecker(ctx)) {
      _uiState.value =
        _uiState.value.copy(
          status = RewardedAdStatus.LOAD_FAILED,
          statusMessage = "No internet connection. Connect and tap Retry to load a video.",
          lastErrorMessage = "No internet connection",
        )
      return
    }

    _uiState.value =
      _uiState.value.copy(
        status = RewardedAdStatus.LOADING,
        statusMessage = "Loading rewarded video...",
      )

    try {
      val loadConfig = LoadConfiguration.Builder(UnityAdsConfig.REWARDED_PLACEMENT_ID).build()
      sdkBridge.load(configuration = loadConfig, callback = loadCallback)
    } catch (t: Throwable) {
      _uiState.value =
        _uiState.value.copy(
          status = RewardedAdStatus.LOAD_FAILED,
          statusMessage = "Could not load ad right now. Tap Retry.",
          lastErrorMessage = t.message ?: "Load exception",
        )
    }
  }

  override fun showRewardedAd(
    activity: Activity,
    onRewardVerified: (coinsAwarded: Int) -> Unit,
    onAdNotRewarded: (reason: String) -> Unit,
  ) {
    if (_uiState.value.status == RewardedAdStatus.SHOWING || activeShowToken != null) {
      onAdNotRewarded("A rewarded ad is already playing.")
      return
    }

    val ad = loadedRewardedAd
    if (_uiState.value.status != RewardedAdStatus.READY || ad == null) {
      onAdNotRewarded("Rewarded ad is not ready yet. Please wait or tap Retry.")
      if (_uiState.value.status == RewardedAdStatus.LOAD_FAILED ||
        _uiState.value.status == RewardedAdStatus.INIT_FAILED
      ) {
        retry()
      }
      return
    }

    if (!connectivityChecker(activity.applicationContext)) {
      _uiState.value =
        _uiState.value.copy(
          status = RewardedAdStatus.LOAD_FAILED,
          statusMessage = "Internet connection lost. Reconnect and tap Retry.",
          lastErrorMessage = "Offline before show",
        )
      onAdNotRewarded("Internet unavailable. Your saved progress is safe.")
      return
    }

    activeShowToken = UUID.randomUUID().toString()
    rewardDeliveredForActiveShow = false
    pendingRewardCallback = onRewardVerified
    pendingNoRewardCallback = onAdNotRewarded

    _uiState.value =
      _uiState.value.copy(
        status = RewardedAdStatus.SHOWING,
        statusMessage = "Launching rewarded video...",
        lastErrorMessage = null,
      )

    try {
      val showConfig = ShowConfiguration.Builder().build()
      ad.show(activity = activity, configuration = showConfig, callbacks = showCallbacks)
    } catch (t: Throwable) {
      activeShowToken = null
      rewardDeliveredForActiveShow = false
      pendingRewardCallback = null
      pendingNoRewardCallback = null
      _uiState.value =
        _uiState.value.copy(
          status = RewardedAdStatus.LOAD_FAILED,
          statusMessage = "Unable to display ad. Tap Retry.",
          lastErrorMessage = t.message ?: "Show exception",
        )
      onAdNotRewarded("Unable to display ad right now.")
    }
  }

  override fun retry() {
    _uiState.value = _uiState.value.copy(lastErrorMessage = null)
    val ctx = appContext
    if (!_uiState.value.isSdkInitialized && !sdkBridge.isInitialized()) {
      if (ctx != null) {
        initialize(ctx)
      }
    } else {
      loadRewardedAd()
    }
  }
}

class RealUnityAdsSdkBridge : UnityAdsSdkBridge {
  override fun isInitialized(): Boolean = UnityAds.isInitialized

  override fun initialize(
    config: InitializationConfiguration,
    onComplete: (errorCode: Int?, errorMessage: String?) -> Unit,
  ) {
    UnityAds.initialize(
      config,
      InitializationListener { error ->
        if (error == null) {
          onComplete(null, null)
        } else {
          onComplete(error.code, error.message)
        }
      },
    )
  }

  override fun load(configuration: LoadConfiguration, callback: RewardedLoadCallback) {
    RewardedAd.load(
      configuration,
      LoadListener<RewardedAd> { ad, error ->
        if (error == null && ad != null) {
          callback.onLoaded(RealLoadedRewardedAd(ad))
        } else {
          callback.onLoadFailed(error?.code, error?.message ?: "Unknown Unity Ads load failure")
        }
      },
    )
  }
}

private class RealLoadedRewardedAd(private val ad: RewardedAd) : LoadedRewardedAd {
  override fun setOnExpired(onExpired: () -> Unit) {
    ad.onAdExpired = AdExpiredListener { onExpired() }
  }

  override fun show(
    activity: Activity,
    configuration: ShowConfiguration,
    callbacks: RewardedShowCallbacks,
  ) {
    ad.show(
      activity,
      configuration,
      object : RewardedShowListener {
        override fun onStarted(ad: RewardedAd) = callbacks.onStarted()

        override fun onClicked(ad: RewardedAd) = callbacks.onClicked()

        override fun onRewarded(ad: RewardedAd) = callbacks.onRewarded()

        override fun onCompleted(ad: RewardedAd, state: ShowFinishState) =
          callbacks.onCompleted(state)

        override fun onFailed(ad: RewardedAd, error: UnityAdsError) =
          callbacks.onFailed(error.code, error.message)
      },
    )
  }
}

fun defaultIsNetworkAvailable(context: Context): Boolean {
  val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
  val activeNetwork = cm.activeNetwork ?: return false
  val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
  return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}
