package com.example.ads

/**
 * Centralized Unity Ads configuration for Ultimate Fun Challenge.
 *
 * Update these identifiers when moving from Unity Ads test mode to production.
 * NOTE: Keep TEST_MODE = true during development and QA to avoid serving real ads
 * or violating Unity Ads invalid-traffic policies.
 */
object UnityAdsConfig {
  /** Unity Project Game ID for Android. */
  const val GAME_ID: String = "800449182"

  /** Rewarded Video Ad Placement / Ad Unit ID for Android. */
  const val REWARDED_PLACEMENT_ID: String = "BP_Rewarded_Android"

  /** Enables Unity Ads test mode during development. */
  const val TEST_MODE: Boolean = true

  /** Number of coins granted only after a verified COMPLETED rewarded ad callback. */
  const val REWARDED_COINS_AMOUNT: Int = 100
}
