package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.GameCatalog
import com.example.data.GameThemeSpec
import com.example.data.PlayerProgress
import com.example.ui.components.ArcadePrimaryButton
import com.example.ui.components.CharacterAvatarCanvas
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.PlasmaViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
  progress: PlayerProgress,
  theme: GameThemeSpec,
  hasDailyPending: Boolean,
  onPlayNextLevel: () -> Unit,
  onOpenLevels: () -> Unit,
  onPlayEndless: () -> Unit,
  onPlayBrainBlitz: () -> Unit,
  onOpenRewards: () -> Unit,
  onOpenShop: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val activeCharacter = GameCatalog.getCharacter(progress.selectedCharacterId)
  val nextLevel = GameCatalog.getLevel(progress.highestUnlockedLevel)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 640.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Hero Arcade Banner Card
      item {
        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(24.dp),
          border = BorderStroke(1.5.dp, theme.primaryAccent.copy(alpha = 0.55f)),
          shadowElevation = 10.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Box(modifier = Modifier.fillMaxWidth().height(216.dp)) {
            Image(
              painter = painterResource(id = R.drawable.img_hero_banner),
              contentDescription = "Ultimate Fun Challenge neon arcade track banner",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
            Box(
              modifier =
                Modifier
                  .fillMaxSize()
                  .background(
                    Brush.verticalGradient(
                      colors =
                        listOf(
                          Color(0x550A081A),
                          Color(0xCC0D0A24),
                          Color(0xF2120E2E),
                        )
                    )
                  )
            )
            Column(
              modifier = Modifier.fillMaxSize().padding(18.dp),
              verticalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Surface(
                  color = theme.primaryAccent.copy(alpha = 0.2f),
                  shape = RoundedCornerShape(50),
                  border = BorderStroke(1.dp, theme.primaryAccent.copy(alpha = 0.65f)),
                ) {
                  Text(
                    text = "LEVEL ${nextLevel.levelNumber} • ${nextLevel.worldName.uppercase()}",
                    style = MaterialTheme.typography.labelMedium,
                    color = theme.primaryAccent,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  )
                }
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier =
                    Modifier
                      .clip(RoundedCornerShape(50))
                      .clickable(onClick = onOpenShop)
                      .padding(4.dp)
                      .testTag("home_character_pill"),
                ) {
                  CharacterAvatarCanvas(
                    character = activeCharacter,
                    modifier = Modifier.size(34.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = activeCharacter.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                  )
                }
              }

              Column {
                Text(
                  text = "ULTIMATE FUN\nCHALLENGE",
                  style = MaterialTheme.typography.displaySmall,
                  color = TextPrimary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "Dodge hazards, crush coin rushes & crack timed brain gates!",
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextSecondary,
                )
              }

              ArcadePrimaryButton(
                text = "PLAY LEVEL ${nextLevel.levelNumber}: ${nextLevel.title.uppercase()}",
                icon = Icons.Filled.PlayArrow,
                containerColor = theme.primaryAccent,
                testTag = "play_next_level_button",
                onClick = onPlayNextLevel,
                modifier = Modifier.fillMaxWidth(),
              )
            }
          }
        }
      }

      // High Score & Progress Strip
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          StatTile(
            label = "BEST SCORE",
            value = progress.totalHighScore.toString(),
            icon = Icons.Filled.EmojiEvents,
            tint = ArcadeGold,
            modifier = Modifier.weight(1f),
          )
          StatTile(
            label = "ENDLESS",
            value = progress.endlessHighScore.toString(),
            icon = Icons.Filled.AllInclusive,
            tint = NeonCyan,
            modifier = Modifier.weight(1f),
          )
          StatTile(
            label = "STARS",
            value = "${progress.totalStars}/105",
            icon = Icons.Filled.Star,
            tint = NeonMagenta,
            modifier = Modifier.weight(1f),
          )
        }
      }

      // Daily Reward / Ad Bonus Highlight Banner
      if (hasDailyPending) {
        item {
          Surface(
            color = Color(0xFF281A06),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.5.dp, ArcadeGold.copy(alpha = 0.8f)),
            modifier =
              Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(18.dp))
                .clickable(onClick = onOpenRewards)
                .testTag("home_daily_reward_banner"),
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.CardGiftcard,
                contentDescription = "Daily reward ready",
                tint = ArcadeGold,
                modifier = Modifier.size(32.dp),
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Daily Reward Ready!",
                  style = MaterialTheme.typography.titleMedium,
                  color = ArcadeGold,
                )
                Text(
                  text = "Claim free streak coins + watch a Unity video for +100 Coins",
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextPrimary,
                )
              }
              Icon(
                imageVector = Icons.Filled.Bolt,
                contentDescription = null,
                tint = ArcadeGold,
              )
            }
          }
        }
      }

      // Game Modes Grid
      item {
        Text(
          text = "GAME MODES",
          style = MaterialTheme.typography.titleMedium,
          color = TextSecondary,
        )
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          ModeCard(
            title = "Endless Runner",
            subtitle = "Infinite speed & escalating gates",
            badge = "BEST ${progress.endlessHighScore}",
            accent = NeonCyan,
            icon = Icons.Filled.AllInclusive,
            testTag = "mode_endless_card",
            onClick = onPlayEndless,
            modifier = Modifier.weight(1f),
          )
          ModeCard(
            title = "Brain Blitz",
            subtitle = "8 timed logic & reflex puzzles",
            badge = "BEST ${progress.brainBlitzHighScore}",
            accent = NeonMagenta,
            icon = Icons.Filled.Psychology,
            testTag = "mode_brain_blitz_card",
            onClick = onPlayBrainBlitz,
            modifier = Modifier.weight(1f),
          )
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          ModeCard(
            title = "35 Campaign Levels",
            subtitle = "5 cyber worlds • Level ${progress.highestUnlockedLevel}/35",
            badge = "SELECT LEVEL",
            accent = ElectricLime,
            icon = Icons.Filled.PlayArrow,
            testTag = "mode_levels_card",
            onClick = onOpenLevels,
            modifier = Modifier.weight(1f),
          )
          ModeCard(
            title = "Free Coin Vault",
            subtitle = "Daily streaks & Unity video rewards",
            badge = "+100 COINS",
            accent = PlasmaViolet,
            icon = Icons.Filled.CardGiftcard,
            testTag = "mode_rewards_card",
            onClick = onOpenRewards,
            modifier = Modifier.weight(1f),
          )
        }
      }

      item { Spacer(modifier = Modifier.height(10.dp)) }
    }
  }
}

@Composable
private fun StatTile(
  label: String,
  value: String,
  icon: ImageVector,
  tint: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = CosmicSurface,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, CosmicBorder),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = tint,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = TextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun ModeCard(
  title: String,
  subtitle: String,
  badge: String,
  accent: Color,
  icon: ImageVector,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = CosmicSurfaceElevated,
    shape = RoundedCornerShape(20.dp),
    border = BorderStroke(1.2.dp, accent.copy(alpha = 0.5f)),
    modifier =
      modifier
        .height(152.dp)
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(20.dp))
        .clickable(onClick = onClick)
        .testTag(testTag),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier =
            Modifier
              .size(38.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(accent.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(imageVector = icon, contentDescription = null, tint = accent)
        }
        Surface(
          color = accent.copy(alpha = 0.16f),
          shape = RoundedCornerShape(50),
        ) {
          Text(
            text = badge,
            style = MaterialTheme.typography.labelMedium,
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            maxLines = 1,
          )
        }
      }
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}
