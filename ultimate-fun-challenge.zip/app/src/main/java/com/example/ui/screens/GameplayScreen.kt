package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ads.RewardedAdStatus
import com.example.ads.RewardedAdUiState
import com.example.ads.UnityAdsConfig
import com.example.data.GameThemeSpec
import com.example.data.PlayerProgress
import com.example.game.BrainPuzzle
import com.example.game.EntityKind
import com.example.game.GameRunState
import com.example.game.RunMode
import com.example.game.RunPhase
import com.example.game.TrackEntity
import com.example.ui.components.ArcadePrimaryButton
import com.example.ui.components.StarRow
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.PlasmaViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

@Composable
fun GameplayScreen(
  runState: GameRunState,
  progress: PlayerProgress,
  theme: GameThemeSpec,
  adUiState: RewardedAdUiState,
  onMoveLeft: () -> Unit,
  onMoveRight: () -> Unit,
  onJump: () -> Unit,
  onSlide: () -> Unit,
  onTogglePause: () -> Unit,
  onRestart: () -> Unit,
  onNextLevel: (Int) -> Unit,
  onAnswerBrainPuzzle: (Int) -> Unit,
  onWatchRewardedAd: (Activity) -> Unit,
  onQuitToHome: () -> Unit,
  modifier: Modifier = Modifier,
) {
  BackHandler {
    if (runState.phase == RunPhase.RUNNING) {
      onTogglePause()
    } else {
      onQuitToHome()
    }
  }

  var dragAccumX by remember { mutableFloatStateOf(0f) }
  var dragAccumY by remember { mutableFloatStateOf(0f) }
  var dragHandled by remember { mutableFloatStateOf(0f) }

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(theme.skyTop)
        .pointerInput(runState.phase) {
          detectDragGestures(
            onDragStart = {
              dragAccumX = 0f
              dragAccumY = 0f
              dragHandled = 0f
            },
            onDrag = { change, dragAmount ->
              change.consume()
              if (dragHandled > 0f || runState.phase != RunPhase.RUNNING) return@detectDragGestures
              dragAccumX += dragAmount.x
              dragAccumY += dragAmount.y
              val threshold = 42f
              if (abs(dragAccumX) > threshold && abs(dragAccumX) > abs(dragAccumY)) {
                dragHandled = 1f
                if (dragAccumX < 0f) onMoveLeft() else onMoveRight()
              } else if (abs(dragAccumY) > threshold && abs(dragAccumY) > abs(dragAccumX)) {
                dragHandled = 1f
                if (dragAccumY < 0f) onJump() else onSlide()
              }
            },
          )
        }
  ) {
    // 60FPS Perspective Arcade Runner Canvas
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawArcadeScene(runState = runState, theme = theme)
    }

    // Floating Popups Layer (Rendered cleanly above track)
    Box(modifier = Modifier.fillMaxSize()) {
      runState.popups.forEach { popup ->
        val alpha = (1f - (popup.ageSec / 1.1f)).coerceIn(0f, 1f)
        Box(
          modifier =
            Modifier
              .align(Alignment.Center)
              .padding(bottom = (90 + popup.ageSec * 85).dp),
        ) {
          Text(
            text = popup.text,
            style = MaterialTheme.typography.titleLarge,
            color = (if (popup.isPositive) ArcadeGold else DangerCoral).copy(alpha = alpha),
          )
        }
      }
    }

    // Top Gameplay HUD
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        // Lives & Shield
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          for (i in 1..runState.maxLives) {
            Icon(
              imageVector = if (i <= runState.lives) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
              contentDescription = "Life $i",
              tint = if (i <= runState.lives) DangerCoral else TextSecondary.copy(alpha = 0.4f),
              modifier = Modifier.size(22.dp),
            )
          }
          if (runState.hasShield) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Filled.Shield,
              contentDescription = "Shield active",
              tint = NeonCyan,
              modifier = Modifier.size(22.dp),
            )
          }
        }

        // Score & Combo
        Surface(
          color = CosmicSurface.copy(alpha = 0.88f),
          shape = RoundedCornerShape(50),
          border = BorderStroke(1.dp, theme.primaryAccent.copy(alpha = 0.6f)),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = runState.score.toString(),
              style = MaterialTheme.typography.titleMedium,
              color = TextPrimary,
            )
            if (runState.combo > 1) {
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "x${runState.combo}",
                style = MaterialTheme.typography.labelMedium,
                color = ArcadeGold,
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Icon(
              imageVector = Icons.Filled.MonetizationOn,
              contentDescription = "Run coins",
              tint = ArcadeGold,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = runState.coinsCollected.toString(),
              style = MaterialTheme.typography.labelLarge,
              color = ArcadeGold,
            )
          }
        }

        IconButton(
          onClick = onTogglePause,
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .size(48.dp)
              .clip(CircleShape)
              .background(CosmicSurface.copy(alpha = 0.85f))
              .testTag("gameplay_pause_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Pause,
            contentDescription = "Pause game",
            tint = TextPrimary,
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Mode & Distance Progress Bar
      val modeTitle =
        when (val m = runState.mode) {
          is RunMode.Campaign -> "LVL ${m.level.levelNumber}: ${m.level.title}"
          RunMode.Endless -> "ENDLESS MODE • ${runState.distance.toInt()}m"
        }
      Surface(
        color = CosmicSurface.copy(alpha = 0.78f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = modeTitle,
              style = MaterialTheme.typography.labelMedium,
              color = theme.primaryAccent,
            )
            if (runState.mode is RunMode.Campaign) {
              Text(
                text = "${runState.distance.toInt()} / ${runState.mode.level.targetDistance.toInt()}m",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          LinearProgressIndicator(
            progress = { runState.progressFraction },
            color = theme.primaryAccent,
            trackColor = CosmicBorder,
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
          )
        }
      }

      // Active Power-ups & Timed Rush Banner
      if (runState.timedRush.active) {
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          color = Color(0xCC2C1600),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, ArcadeGold),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Bolt, contentDescription = null, tint = ArcadeGold, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "COIN RUSH: ${runState.timedRush.coinsCollected}/${runState.timedRush.coinGoal}",
                style = MaterialTheme.typography.labelLarge,
                color = ArcadeGold,
              )
            }
            Text(
              text = "${runState.timedRush.timeRemainingSec.toInt() + 1}s",
              style = MaterialTheme.typography.labelLarge,
              color = TextPrimary,
            )
          }
        }
      }
    }

    // Bottom Tactile Controls (works alongside swipes!)
    if (runState.phase == RunPhase.RUNNING) {
      Row(
        modifier =
          Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          ArcadeControlPadButton(
            icon = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
            label = "LEFT",
            accent = theme.primaryAccent,
            testTag = "control_left_button",
            onClick = onMoveLeft,
          )
          ArcadeControlPadButton(
            icon = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            label = "RIGHT",
            accent = theme.primaryAccent,
            testTag = "control_right_button",
            onClick = onMoveRight,
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          ArcadeControlPadButton(
            icon = Icons.Filled.KeyboardArrowDown,
            label = "SLIDE",
            accent = theme.secondaryAccent,
            testTag = "control_slide_button",
            onClick = onSlide,
          )
          ArcadeControlPadButton(
            icon = Icons.Filled.KeyboardArrowUp,
            label = "JUMP",
            accent = ElectricLime,
            testTag = "control_jump_button",
            onClick = onJump,
          )
        }
      }
    }

    // Brain Gate Mid-Run Puzzle Overlay
    val activePuzzle = runState.activeBrainPuzzle
    if (runState.phase == RunPhase.BRAIN_GATE && activePuzzle != null) {
      BrainGateOverlay(
        puzzle = activePuzzle,
        timeLeftSec = runState.brainPuzzleTimeLeft,
        onAnswer = onAnswerBrainPuzzle,
      )
    }

    // Pause Overlay
    if (runState.phase == RunPhase.PAUSED) {
      PauseOverlay(
        onResume = onTogglePause,
        onRestart = onRestart,
        onQuit = onQuitToHome,
      )
    }

    // Level Complete Overlay
    if (runState.phase == RunPhase.LEVEL_COMPLETE && runState.mode is RunMode.Campaign) {
      LevelCompleteOverlay(
        runState = runState,
        levelNumber = runState.mode.level.levelNumber,
        onNextLevel = { onNextLevel(runState.mode.level.levelNumber + 1) },
        onReplay = onRestart,
        onQuit = onQuitToHome,
      )
    }

    // Game Over Overlay
    if (runState.phase == RunPhase.GAME_OVER) {
      val context = LocalContext.current
      val activity = context as? Activity
      GameOverOverlay(
        runState = runState,
        bestTotalScore = progress.totalHighScore,
        adUiState = adUiState,
        onRestart = onRestart,
        onWatchAd = { activity?.let(onWatchRewardedAd) },
        onQuit = onQuitToHome,
      )
    }
  }
}

@Composable
private fun ArcadeControlPadButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  accent: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    color = CosmicSurface.copy(alpha = 0.84f),
    shape = RoundedCornerShape(18.dp),
    border = BorderStroke(1.5.dp, accent.copy(alpha = 0.7f)),
    modifier =
      Modifier
        .size(width = 72.dp, height = 62.dp)
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onClick)
        .testTag(testTag),
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = accent,
        modifier = Modifier.size(28.dp),
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = TextPrimary,
        fontSize = 10.sp,
      )
    }
  }
}

@Composable
private fun BrainGateOverlay(
  puzzle: BrainPuzzle,
  timeLeftSec: Float,
  onAnswer: (Int) -> Unit,
) {
  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(Color(0xD6080618))
        .padding(18.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      color = CosmicSurface,
      shape = RoundedCornerShape(24.dp),
      border = BorderStroke(2.dp, NeonCyan),
      modifier = Modifier.widthIn(max = 500.dp).fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Surface(
            color = NeonMagenta.copy(alpha = 0.22f),
            shape = RoundedCornerShape(50),
          ) {
            Text(
              text = "BRAIN GATE • ${puzzle.kind.badge}",
              style = MaterialTheme.typography.labelMedium,
              color = NeonMagenta,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
          Text(
            text = "${timeLeftSec.toInt() + 1}s",
            style = MaterialTheme.typography.titleMedium,
            color = if (timeLeftSec < 3f) DangerCoral else ArcadeGold,
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { (timeLeftSec / puzzle.timeLimitSec).coerceIn(0f, 1f) },
          color = if (timeLeftSec < 3f) DangerCoral else NeonCyan,
          trackColor = CosmicBorder,
          modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
        )

        Spacer(modifier = Modifier.height(14.dp))
        Image(
          painter = painterResource(id = R.drawable.img_brain_art),
          contentDescription = "Brain challenge portal",
          contentScale = ContentScale.Crop,
          modifier = Modifier.size(90.dp).clip(RoundedCornerShape(18.dp)),
        )
        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = puzzle.question,
          style = MaterialTheme.typography.titleMedium,
          color = TextSecondary,
          textAlign = TextAlign.Center,
        )
        if (!puzzle.highlightValue.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = puzzle.highlightValue,
            style = MaterialTheme.typography.headlineMedium,
            color = puzzle.highlightColor ?: TextPrimary,
            textAlign = TextAlign.Center,
          )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          puzzle.options.chunked(2).forEachIndexed { rowIdx, pair ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              pair.forEachIndexed { colIdx, option ->
                val idx = rowIdx * 2 + colIdx
                val btnColor = option.colorTint ?: CosmicSurfaceElevated
                val textColor = if (option.colorTint != null) Color(0xFF07101A) else TextPrimary
                Surface(
                  color = btnColor,
                  shape = RoundedCornerShape(14.dp),
                  border = BorderStroke(1.5.dp, option.colorTint ?: NeonCyan.copy(alpha = 0.6f)),
                  modifier =
                    Modifier
                      .weight(1f)
                      .height(54.dp)
                      .minimumInteractiveComponentSize()
                      .clip(RoundedCornerShape(14.dp))
                      .clickable { onAnswer(idx) }
                      .testTag("brain_gate_option_$idx"),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      text = option.label,
                      style = MaterialTheme.typography.titleMedium,
                      color = textColor,
                      fontWeight = FontWeight.Bold,
                    )
                  }
                }
              }
            }
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "Reward: +${puzzle.bonusCoins} Coins & Energy Shield",
          style = MaterialTheme.typography.labelMedium,
          color = ElectricLime,
        )
      }
    }
  }
}

@Composable
private fun PauseOverlay(
  onResume: () -> Unit,
  onRestart: () -> Unit,
  onQuit: () -> Unit,
) {
  Box(
    modifier = Modifier.fillMaxSize().background(Color(0xCC070515)).padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      color = CosmicSurface,
      shape = RoundedCornerShape(24.dp),
      border = BorderStroke(1.5.dp, NeonCyan.copy(alpha = 0.7f)),
      modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(text = "GAME PAUSED", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        ArcadePrimaryButton(
          text = "RESUME",
          icon = Icons.Filled.PlayArrow,
          containerColor = NeonCyan,
          testTag = "pause_resume_button",
          onClick = onResume,
          modifier = Modifier.fillMaxWidth(),
        )
        ArcadePrimaryButton(
          text = "RESTART RUN",
          icon = Icons.Filled.Refresh,
          containerColor = ArcadeGold,
          testTag = "pause_restart_button",
          onClick = onRestart,
          modifier = Modifier.fillMaxWidth(),
        )
        ArcadePrimaryButton(
          text = "EXIT TO HUB",
          icon = Icons.AutoMirrored.Filled.ArrowBack,
          containerColor = CosmicSurfaceElevated,
          contentColor = TextPrimary,
          testTag = "pause_exit_button",
          onClick = onQuit,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun LevelCompleteOverlay(
  runState: GameRunState,
  levelNumber: Int,
  onNextLevel: () -> Unit,
  onReplay: () -> Unit,
  onQuit: () -> Unit,
) {
  Box(
    modifier = Modifier.fillMaxSize().background(Color(0xD4070515)).padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      color = CosmicSurface,
      shape = RoundedCornerShape(24.dp),
      border = BorderStroke(2.dp, ArcadeGold),
      modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.EmojiEvents,
          contentDescription = "Level complete trophy",
          tint = ArcadeGold,
          modifier = Modifier.size(48.dp),
        )
        Text(
          text = "LEVEL $levelNumber COMPLETE!",
          style = MaterialTheme.typography.headlineMedium,
          color = ArcadeGold,
          textAlign = TextAlign.Center,
        )
        StarRow(stars = runState.earnedStars, starSize = 36.dp)
        Text(
          text = "Score: ${runState.score} • Coins: +${runState.coinsCollected + runState.completionBonusCoins}",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary,
        )
        if (levelNumber < 35) {
          ArcadePrimaryButton(
            text = "NEXT LEVEL (${levelNumber + 1})",
            icon = Icons.Filled.PlayArrow,
            containerColor = ElectricLime,
            testTag = "level_complete_next_button",
            onClick = onNextLevel,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        ArcadePrimaryButton(
          text = "REPLAY LEVEL",
          icon = Icons.Filled.Refresh,
          containerColor = NeonCyan,
          testTag = "level_complete_replay_button",
          onClick = onReplay,
          modifier = Modifier.fillMaxWidth(),
        )
        ArcadePrimaryButton(
          text = "BACK TO HUB",
          icon = Icons.Filled.Home,
          containerColor = CosmicSurfaceElevated,
          contentColor = TextPrimary,
          testTag = "level_complete_home_button",
          onClick = onQuit,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun GameOverOverlay(
  runState: GameRunState,
  bestTotalScore: Int,
  adUiState: RewardedAdUiState,
  onRestart: () -> Unit,
  onWatchAd: () -> Unit,
  onQuit: () -> Unit,
) {
  Box(
    modifier = Modifier.fillMaxSize().background(Color(0xD80A0412)).padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      color = CosmicSurface,
      shape = RoundedCornerShape(24.dp),
      border = BorderStroke(2.dp, DangerCoral),
      modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "RUN OVER",
          style = MaterialTheme.typography.displaySmall,
          color = DangerCoral,
        )
        Text(
          text = "Score: ${runState.score}  •  Best: ${maxOf(bestTotalScore, runState.score)}",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary,
        )
        Text(
          text = "Banked +${runState.coinsCollected} Coins!",
          style = MaterialTheme.typography.bodyLarge,
          color = ArcadeGold,
        )

        ArcadePrimaryButton(
          text = "TRY AGAIN",
          icon = Icons.Filled.Refresh,
          containerColor = NeonCyan,
          testTag = "gameover_restart_button",
          onClick = onRestart,
          modifier = Modifier.fillMaxWidth(),
        )

        if (adUiState.status == RewardedAdStatus.READY) {
          ArcadePrimaryButton(
            text = "WATCH AD (+${UnityAdsConfig.REWARDED_COINS_AMOUNT} COINS)",
            icon = Icons.Filled.OndemandVideo,
            containerColor = ArcadeGold,
            testTag = "gameover_watch_ad_button",
            onClick = onWatchAd,
            modifier = Modifier.fillMaxWidth(),
          )
        }

        ArcadePrimaryButton(
          text = "BACK TO HUB",
          icon = Icons.Filled.Home,
          containerColor = CosmicSurfaceElevated,
          contentColor = TextPrimary,
          testTag = "gameover_home_button",
          onClick = onQuit,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

private fun DrawScope.drawArcadeScene(runState: GameRunState, theme: GameThemeSpec) {
  val w = size.width
  val h = size.height
  val shakeX =
    if (runState.shakeTimer > 0f) sin(runState.shakeTimer * 70f) * 10.dp.toPx() else 0f
  val shakeY =
    if (runState.shakeTimer > 0f) cos(runState.shakeTimer * 60f) * 8.dp.toPx() else 0f

  val horizonY = h * 0.25f + shakeY
  val trackBottomY = h * 0.92f + shakeY
  val topHalfWidth = w * 0.14f
  val bottomHalfWidth = w * 0.46f
  val centerX = w * 0.5f + shakeX

  // Sky Gradient
  drawRect(
    brush = Brush.verticalGradient(listOf(theme.skyTop, theme.skyBottom)),
    size = Size(w, horizonY + 24f),
  )

  // Horizon Neon Sun/Portal Glow
  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(theme.secondaryAccent.copy(alpha = 0.55f), Color.Transparent),
        center = Offset(centerX, horizonY),
        radius = w * 0.45f,
      ),
    radius = w * 0.45f,
    center = Offset(centerX, horizonY),
  )

  // Starfield in sky
  for (i in 0..18) {
    val sx = ((i * 73 + 19) % 100) / 100f * w
    val sy = ((i * 41 + 7) % 100) / 100f * (horizonY * 0.85f)
    drawCircle(Color.White.copy(alpha = 0.45f), radius = (1.5f + (i % 3)).toFloat(), center = Offset(sx, sy))
  }

  // Perspective Track Polygon
  val trackPath =
    Path().apply {
      moveTo(centerX - topHalfWidth, horizonY)
      lineTo(centerX + topHalfWidth, horizonY)
      lineTo(centerX + bottomHalfWidth, trackBottomY)
      lineTo(centerX - bottomHalfWidth, trackBottomY)
      close()
    }
  drawPath(trackPath, color = theme.trackSurface)

  // Below track floor fill
  drawRect(
    color = theme.skyTop,
    topLeft = Offset(0f, trackBottomY),
    size = Size(w, h - trackBottomY),
  )

  // Perspective horizontal speed lines
  for (i in 0..10) {
    val rawT = ((i / 10f) + (1f - runState.trackScrollOffset)) % 1f
    val persp = rawT.pow(1.9f)
    val y = horizonY + (trackBottomY - horizonY) * persp
    val halfW = topHalfWidth + (bottomHalfWidth - topHalfWidth) * persp
    drawLine(
      color = theme.gridLine.copy(alpha = 0.12f + 0.25f * persp),
      start = Offset(centerX - halfW, y),
      end = Offset(centerX + halfW, y),
      strokeWidth = 1.5f + 2f * persp,
    )
  }

  // 4 Lane Divider Rails (3 lanes)
  for (rail in 0..3) {
    val norm = -1f + (rail / 3f) * 2f
    val topX = centerX + topHalfWidth * norm
    val botX = centerX + bottomHalfWidth * norm
    val isOuter = rail == 0 || rail == 3
    drawLine(
      color = if (isOuter) theme.primaryAccent else theme.gridLine.copy(alpha = 0.45f),
      start = Offset(topX, horizonY),
      end = Offset(botX, trackBottomY),
      strokeWidth = if (isOuter) 4.dp.toPx() else 2.dp.toPx(),
    )
  }

  // Entities sorted far-to-near (z descending)
  val sorted = runState.entities.sortedByDescending { it.z }
  for (entity in sorted) {
    drawTrackEntity(
      entity = entity,
      centerX = centerX,
      horizonY = horizonY,
      trackBottomY = trackBottomY,
      topHalfWidth = topHalfWidth,
      bottomHalfWidth = bottomHalfWidth,
      theme = theme,
    )
  }

  // Player Sprite
  val playerZ = 0.08f
  val playerPersp = (1f - playerZ).pow(1.85f)
  val playerTrackY = horizonY + (trackBottomY - horizonY) * playerPersp
  val playerHalfW = topHalfWidth + (bottomHalfWidth - topHalfWidth) * playerPersp
  val laneNorm = (runState.visualLane - 1f) * 0.66f
  val playerX = centerX + playerHalfW * laneNorm
  val jumpLift = runState.jumpHeight * 95.dp.toPx()
  val isSliding = runState.slideTimer > 0f
  val playerSize = if (isSliding) 32.dp.toPx() else 46.dp.toPx()
  val playerWidth = if (isSliding) 50.dp.toPx() else 42.dp.toPx()
  val playerY = playerTrackY - jumpLift - playerSize * 0.55f

  // Track Shadow under player
  drawOval(
    color = Color.Black.copy(alpha = (0.45f - runState.jumpHeight * 0.25f).coerceAtLeast(0.15f)),
    topLeft = Offset(playerX - 22.dp.toPx(), playerTrackY - 6.dp.toPx()),
    size = Size(44.dp.toPx(), 12.dp.toPx()),
  )

  val blinkSkip = runState.invincibleTimer > 0f && ((runState.invincibleTimer * 18f).toInt() % 2 == 0)
  if (!blinkSkip) {
    // Boost / Trail glow
    if (runState.boostTimer > 0f) {
      drawCircle(
        color = ArcadeGold.copy(alpha = 0.35f),
        radius = 38.dp.toPx(),
        center = Offset(playerX, playerY),
      )
    }
    // Character Body
    drawRoundRect(
      color = runState.character.bodyColor,
      topLeft = Offset(playerX - playerWidth / 2f, playerY - playerSize / 2f),
      size = Size(playerWidth, playerSize),
      cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx()),
    )
    // Character Visor
    drawRoundRect(
      color = Color(0xFF0A081A),
      topLeft = Offset(playerX - playerWidth * 0.34f, playerY - playerSize * 0.22f),
      size = Size(playerWidth * 0.68f, playerSize * 0.26f),
      cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
    )
    drawCircle(
      color = runState.character.accentColor,
      radius = 3.5.dp.toPx(),
      center = Offset(playerX - playerWidth * 0.16f, playerY - playerSize * 0.09f),
    )
    drawCircle(
      color = runState.character.accentColor,
      radius = 3.5.dp.toPx(),
      center = Offset(playerX + playerWidth * 0.16f, playerY - playerSize * 0.09f),
    )
    // Active Shield Ring
    if (runState.hasShield) {
      drawCircle(
        color = NeonCyan.copy(alpha = 0.78f),
        radius = 34.dp.toPx(),
        center = Offset(playerX, playerY),
        style = Stroke(width = 3.dp.toPx()),
      )
    }
  }
}

private fun DrawScope.drawTrackEntity(
  entity: TrackEntity,
  centerX: Float,
  horizonY: Float,
  trackBottomY: Float,
  topHalfWidth: Float,
  bottomHalfWidth: Float,
  theme: GameThemeSpec,
) {
  val clampedZ = entity.z.coerceIn(0f, 1f)
  val persp = (1f - clampedZ).pow(1.85f)
  val y = horizonY + (trackBottomY - horizonY) * persp
  val halfW = topHalfWidth + (bottomHalfWidth - topHalfWidth) * persp
  val scale = 0.22f + 0.88f * persp
  val laneNorm = (entity.currentVisualLane - 1f) * 0.66f
  val x = centerX + halfW * laneNorm

  when (entity.kind) {
    EntityKind.COIN -> {
      val r = 15.dp.toPx() * scale
      drawCircle(color = ArcadeGold, radius = r, center = Offset(x, y - r))
      drawCircle(color = Color(0xFFFFF59D), radius = r * 0.55f, center = Offset(x, y - r))
    }
    EntityKind.STAR_GEM -> {
      val r = 19.dp.toPx() * scale
      val diamond =
        Path().apply {
          moveTo(x, y - r * 2f)
          lineTo(x + r, y - r)
          lineTo(x, y)
          lineTo(x - r, y - r)
          close()
        }
      drawPath(diamond, color = NeonCyan)
    }
    EntityKind.SHIELD_ORB -> {
      val r = 18.dp.toPx() * scale
      drawCircle(color = NeonCyan.copy(alpha = 0.35f), radius = r * 1.3f, center = Offset(x, y - r))
      drawCircle(color = NeonCyan, radius = r, center = Offset(x, y - r), style = Stroke(width = 3.dp.toPx() * scale))
    }
    EntityKind.MAGNET_ORB -> {
      val r = 18.dp.toPx() * scale
      drawCircle(color = PlasmaViolet, radius = r, center = Offset(x, y - r))
      drawCircle(color = Color.White, radius = r * 0.45f, center = Offset(x, y - r))
    }
    EntityKind.BOOST_ORB -> {
      val r = 18.dp.toPx() * scale
      drawCircle(color = ElectricLime, radius = r, center = Offset(x, y - r))
    }
    EntityKind.LOW_BARRIER -> {
      val bw = 54.dp.toPx() * scale
      val bh = 28.dp.toPx() * scale
      drawRoundRect(
        color = Color(0xFFFF6D00),
        topLeft = Offset(x - bw / 2f, y - bh),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(6.dp.toPx() * scale),
      )
      drawLine(
        color = Color.White,
        start = Offset(x - bw * 0.3f, y - bh * 0.5f),
        end = Offset(x + bw * 0.3f, y - bh * 0.5f),
        strokeWidth = 3.dp.toPx() * scale,
      )
    }
    EntityKind.HIGH_DRONE -> {
      val bw = 52.dp.toPx() * scale
      val bh = 26.dp.toPx() * scale
      val hoverY = y - 48.dp.toPx() * scale
      drawRoundRect(
        color = NeonMagenta,
        topLeft = Offset(x - bw / 2f, hoverY - bh),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(12.dp.toPx() * scale),
      )
      drawCircle(color = Color.White, radius = 5.dp.toPx() * scale, center = Offset(x, hoverY - bh * 0.5f))
    }
    EntityKind.LASER_WALL -> {
      val bw = 56.dp.toPx() * scale
      val bh = 74.dp.toPx() * scale
      drawRoundRect(
        color = DangerCoral,
        topLeft = Offset(x - bw / 2f, y - bh),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(8.dp.toPx() * scale),
      )
      drawRoundRect(
        color = Color.White.copy(alpha = 0.65f),
        topLeft = Offset(x - bw * 0.22f, y - bh * 0.9f),
        size = Size(bw * 0.44f, bh * 0.8f),
        cornerRadius = CornerRadius(4.dp.toPx() * scale),
      )
    }
    EntityKind.SWEEPER_BOT -> {
      val r = 24.dp.toPx() * scale
      drawCircle(color = DangerCoral, radius = r, center = Offset(x, y - r))
      drawCircle(color = ArcadeGold, radius = r * 0.5f, center = Offset(x, y - r))
    }
    EntityKind.BRAIN_GATE_PORTAL -> {
      val archH = 110.dp.toPx() * scale
      drawRect(
        brush =
          Brush.horizontalGradient(
            listOf(NeonCyan.copy(alpha = 0.4f), NeonMagenta.copy(alpha = 0.45f), ArcadeGold.copy(alpha = 0.4f))
          ),
        topLeft = Offset(centerX - halfW, y - archH),
        size = Size(halfW * 2f, archH),
      )
      drawRect(
        color = theme.primaryAccent,
        topLeft = Offset(centerX - halfW, y - archH),
        size = Size(halfW * 2f, archH),
        style = Stroke(width = 4.dp.toPx() * scale),
      )
    }
  }
}
