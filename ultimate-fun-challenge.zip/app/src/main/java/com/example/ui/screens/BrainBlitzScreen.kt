package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.BrainBlitzState
import com.example.R
import com.example.data.GameThemeSpec
import com.example.ui.components.ArcadePrimaryButton
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun BrainBlitzScreen(
  blitz: BrainBlitzState,
  theme: GameThemeSpec,
  onAnswer: (Int) -> Unit,
  onRestart: () -> Unit,
  onBackHome: () -> Unit,
  modifier: Modifier = Modifier,
) {
  BackHandler { onBackHome() }

  Box(
    modifier = modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier.widthIn(max = 560.dp).fillMaxSize(),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        IconButton(
          onClick = onBackHome,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("brain_blitz_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back to home",
            tint = TextPrimary,
          )
        }

        Text(
          text = "BRAIN BLITZ",
          style = MaterialTheme.typography.titleLarge,
          color = theme.primaryAccent,
        )

        Surface(
          color = CosmicSurfaceElevated,
          shape = RoundedCornerShape(50),
          border = BorderStroke(1.dp, ArcadeGold.copy(alpha = 0.6f)),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Filled.MonetizationOn, contentDescription = null, tint = ArcadeGold, modifier = Modifier.size(16.dp))
            Text(
              text = " +${blitz.coinsEarned}",
              style = MaterialTheme.typography.labelLarge,
              color = ArcadeGold,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (blitz.finished) {
        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(24.dp),
          border = BorderStroke(2.dp, ElectricLime),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Psychology,
              contentDescription = null,
              tint = ElectricLime,
              modifier = Modifier.size(54.dp),
            )
            Text(
              text = "BLITZ COMPLETE!",
              style = MaterialTheme.typography.headlineMedium,
              color = ElectricLime,
            )
            Text(
              text = "Solved ${blitz.correctCount} / ${blitz.totalRounds} Challenges",
              style = MaterialTheme.typography.titleMedium,
              color = TextPrimary,
            )
            Text(
              text = "Score: ${blitz.score}  •  Coins Won: +${blitz.coinsEarned}",
              style = MaterialTheme.typography.titleMedium,
              color = ArcadeGold,
            )
            ArcadePrimaryButton(
              text = "PLAY AGAIN",
              icon = Icons.Filled.Refresh,
              containerColor = NeonCyan,
              testTag = "brain_blitz_replay_button",
              onClick = onRestart,
              modifier = Modifier.fillMaxWidth(),
            )
            ArcadePrimaryButton(
              text = "BACK TO HUB",
              icon = Icons.Filled.Home,
              containerColor = CosmicSurfaceElevated,
              contentColor = TextPrimary,
              testTag = "brain_blitz_home_button",
              onClick = onBackHome,
              modifier = Modifier.fillMaxWidth(),
            )
          }
        }
      } else if (blitz.puzzle != null) {
        val puzzle = blitz.puzzle
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "ROUND ${blitz.round} / ${blitz.totalRounds}",
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondary,
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.LocalFireDepartment,
              contentDescription = "Streak",
              tint = NeonMagenta,
              modifier = Modifier.size(18.dp),
            )
            Text(
              text = " Streak x${blitz.streak}",
              style = MaterialTheme.typography.labelLarge,
              color = NeonMagenta,
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { (blitz.timeLeftSec / puzzle.timeLimitSec).coerceIn(0f, 1f) },
          color = if (blitz.timeLeftSec < 3f) DangerCoral else NeonCyan,
          trackColor = CosmicBorder,
          modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(5.dp)),
        )

        if (!blitz.lastFeedback.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = blitz.lastFeedback,
            style = MaterialTheme.typography.labelLarge,
            color = ArcadeGold,
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(24.dp),
          border = BorderStroke(1.5.dp, theme.primaryAccent.copy(alpha = 0.65f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_brain_art),
              contentDescription = "Brain Blitz visual",
              contentScale = ContentScale.Crop,
              modifier = Modifier.size(104.dp).clip(RoundedCornerShape(18.dp)),
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = puzzle.kind.badge,
              style = MaterialTheme.typography.labelMedium,
              color = NeonMagenta,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = puzzle.question,
              style = MaterialTheme.typography.titleMedium,
              color = TextSecondary,
              textAlign = TextAlign.Center,
            )
            if (!puzzle.highlightValue.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = puzzle.highlightValue,
                style = MaterialTheme.typography.displaySmall,
                color = puzzle.highlightColor ?: TextPrimary,
                textAlign = TextAlign.Center,
              )
            }
            Spacer(modifier = Modifier.height(18.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              puzzle.options.chunked(2).forEachIndexed { rIdx, pair ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  pair.forEachIndexed { cIdx, option ->
                    val idx = rIdx * 2 + cIdx
                    val bg = option.colorTint ?: CosmicSurfaceElevated
                    val fg = if (option.colorTint != null) Color(0xFF06101B) else TextPrimary
                    Surface(
                      color = bg,
                      shape = RoundedCornerShape(16.dp),
                      border = BorderStroke(1.5.dp, option.colorTint ?: theme.primaryAccent.copy(alpha = 0.6f)),
                      modifier =
                        Modifier
                          .weight(1f)
                          .height(58.dp)
                          .minimumInteractiveComponentSize()
                          .clip(RoundedCornerShape(16.dp))
                          .clickable { onAnswer(idx) }
                          .testTag("brain_blitz_option_$idx"),
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        Text(
                          text = option.label,
                          style = MaterialTheme.typography.titleLarge,
                          color = fg,
                          fontWeight = FontWeight.Bold,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
