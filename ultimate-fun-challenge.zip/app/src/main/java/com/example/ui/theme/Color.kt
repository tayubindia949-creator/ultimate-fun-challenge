package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpaceBg = Color(0xFF0A081A)
val CosmicSurface = Color(0xFF151232)
val CosmicSurfaceElevated = Color(0xFF1F1A47)
val CosmicBorder = Color(0xFF332D6B)

val NeonCyan = Color(0xFF00E5FF)
val NeonMagenta = Color(0xFFFF2E93)
val ArcadeGold = Color(0xFFFFCA28)
val ElectricLime = Color(0xFF39FF88)
val PlasmaViolet = Color(0xFF9D4EDD)
val DangerCoral = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF6F7FF)
val TextSecondary = Color(0xFFB5B9E0)
