package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.AppDestination
import com.example.MainViewModel
import com.example.data.GameCatalog
import com.example.ui.components.ArcadeBackground
import com.example.ui.components.ArcadeBottomNavBar
import com.example.ui.components.ArcadeTopHeader
import com.example.ui.screens.BrainBlitzScreen
import com.example.ui.screens.GameplayScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelsScreen
import com.example.ui.screens.RewardsScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.UltimateFunChallengeTheme
import java.util.concurrent.TimeUnit

@Composable
fun UltimateFunChallengeApp(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier,
) {
  val progress by viewModel.progress.collectAsStateWithLifecycle()
  val destination by viewModel.destination.collectAsStateWithLifecycle()
  val runState by viewModel.runState.collectAsStateWithLifecycle()
  val brainBlitz by viewModel.brainBlitz.collectAsStateWithLifecycle()
  val adUiState by viewModel.adUiState.collectAsStateWithLifecycle()
  val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()

  val activeTheme = GameCatalog.getTheme(progress.selectedThemeId)
  val currentEpochDay = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis())
  val hasDailyPending = progress.canClaimDaily(currentEpochDay)

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(bannerMessage) {
    val msg = bannerMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearBannerMessage()
    }
  }

  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_RESUME -> viewModel.soundEngine.onAppResume()
        Lifecycle.Event.ON_PAUSE -> {
          viewModel.soundEngine.onAppPause()
          viewModel.pauseRunIfActive()
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  if (destination != AppDestination.HOME && destination != AppDestination.GAMEPLAY) {
    BackHandler { viewModel.navigateBack() }
  }

  UltimateFunChallengeTheme(accentOverride = activeTheme.primaryAccent) {
    Scaffold(
      modifier = modifier.fillMaxSize(),
      containerColor = Color.Transparent,
      snackbarHost = {
        SnackbarHost(hostState = snackbarHostState) { data ->
          Snackbar(
            snackbarData = data,
            containerColor = CosmicSurfaceElevated,
            contentColor = TextPrimary,
            shape = RoundedCornerShape(14.dp),
          )
        }
      },
    ) { _ ->
      if (destination == AppDestination.GAMEPLAY && runState != null) {
        GameplayScreen(
          runState = runState!!,
          progress = progress,
          theme = activeTheme,
          adUiState = adUiState,
          onMoveLeft = viewModel::onMoveLeft,
          onMoveRight = viewModel::onMoveRight,
          onJump = viewModel::onJump,
          onSlide = viewModel::onSlide,
          onTogglePause = viewModel::togglePauseRun,
          onRestart = viewModel::restartRun,
          onNextLevel = { nextLvl -> viewModel.startCampaignLevel(nextLvl) },
          onAnswerBrainPuzzle = viewModel::onAnswerRunBrainPuzzle,
          onWatchRewardedAd = viewModel::watchRewardedAd,
          onQuitToHome = { viewModel.navigateTo(AppDestination.HOME) },
        )
      } else if (destination == AppDestination.BRAIN_BLITZ) {
        ArcadeBackground(theme = activeTheme) {
          BrainBlitzScreen(
            blitz = brainBlitz,
            theme = activeTheme,
            onAnswer = viewModel::answerBrainBlitz,
            onRestart = viewModel::startBrainBlitz,
            onBackHome = { viewModel.navigateTo(AppDestination.HOME) },
          )
        }
      } else {
        ArcadeBackground(theme = activeTheme) {
          BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 700.dp
            Row(modifier = Modifier.fillMaxSize()) {
              if (useRail) {
                NavigationRail(
                  containerColor = CosmicSurface.copy(alpha = 0.94f),
                  modifier = Modifier.fillMaxHeight().statusBarsPadding(),
                ) {
                  val tabs =
                    listOf(
                      Triple(AppDestination.HOME, "Play", Icons.Filled.Home),
                      Triple(AppDestination.LEVELS, "Levels", Icons.Filled.GridView),
                      Triple(AppDestination.SHOP, "Shop", Icons.Filled.Storefront),
                      Triple(AppDestination.REWARDS, "Rewards", Icons.Filled.CardGiftcard),
                    )
                  tabs.forEach { (dest, label, icon) ->
                    NavigationRailItem(
                      selected = destination == dest,
                      onClick = { viewModel.navigateTo(dest) },
                      icon = { Icon(icon, contentDescription = label) },
                      label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                    )
                  }
                }
              }

              Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                val headerTitle =
                  when (destination) {
                    AppDestination.HOME -> "Ultimate Fun"
                    AppDestination.LEVELS -> "35 Levels"
                    AppDestination.SHOP -> "Arcade Shop"
                    AppDestination.REWARDS -> "Rewards & Ads"
                    else -> "Ultimate Fun"
                  }

                ArcadeTopHeader(
                  title = headerTitle,
                  coins = progress.coins,
                  sfxMuted = progress.sfxMuted,
                  bgmMuted = progress.bgmMuted,
                  onToggleSfx = viewModel::toggleSfxMute,
                  onToggleBgm = viewModel::toggleBgmMute,
                  accentColor = activeTheme.primaryAccent,
                )

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                  Crossfade(targetState = destination, label = "tab_crossfade") { tab ->
                    when (tab) {
                      AppDestination.HOME ->
                        HomeScreen(
                          progress = progress,
                          theme = activeTheme,
                          hasDailyPending = hasDailyPending,
                          onPlayNextLevel = { viewModel.startCampaignLevel(progress.highestUnlockedLevel) },
                          onOpenLevels = { viewModel.navigateTo(AppDestination.LEVELS) },
                          onPlayEndless = viewModel::startEndlessRun,
                          onPlayBrainBlitz = viewModel::startBrainBlitz,
                          onOpenRewards = { viewModel.navigateTo(AppDestination.REWARDS) },
                          onOpenShop = { viewModel.navigateTo(AppDestination.SHOP) },
                        )
                      AppDestination.LEVELS ->
                        LevelsScreen(
                          progress = progress,
                          theme = activeTheme,
                          onSelectLevel = viewModel::startCampaignLevel,
                        )
                      AppDestination.SHOP ->
                        ShopScreen(
                          progress = progress,
                          theme = activeTheme,
                          onSelectOrBuyCharacter = viewModel::selectOrBuyCharacter,
                          onSelectOrBuyTheme = viewModel::selectOrBuyTheme,
                        )
                      AppDestination.REWARDS ->
                        RewardsScreen(
                          progress = progress,
                          theme = activeTheme,
                          adUiState = adUiState,
                          currentEpochDay = currentEpochDay,
                          onClaimDaily = viewModel::claimDailyReward,
                          onWatchAd = viewModel::watchRewardedAd,
                          onRetryAd = viewModel::retryRewardedAd,
                        )
                      else -> Unit
                    }
                  }
                }

                if (!useRail) {
                  ArcadeBottomNavBar(
                    current = destination,
                    accentColor = activeTheme.primaryAccent,
                    hasDailyPending = hasDailyPending,
                    onNavigate = viewModel::navigateTo,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
