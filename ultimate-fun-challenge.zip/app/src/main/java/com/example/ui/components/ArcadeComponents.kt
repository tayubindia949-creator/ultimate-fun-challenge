package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.AppDestination
import com.example.data.GameThemeSpec
import com.example.data.RunnerCharacterSpec
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ArcadeBackground(
  theme: GameThemeSpec,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit,
) {
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(theme.skyTop, theme.skyBottom, theme.trackSurface),
          )
        )
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val step = 64.dp.toPx()
      var x = 0f
      while (x < size.width) {
        drawLine(
          color = theme.gridLine.copy(alpha = 0.06f),
          start = Offset(x, 0f),
          end = Offset(x, size.height),
          strokeWidth = 1f,
        )
        x += step
      }
      var y = 0f
      while (y < size.height) {
        drawLine(
          color = theme.gridLine.copy(alpha = 0.06f),
          start = Offset(0f, y),
          end = Offset(size.width, y),
          strokeWidth = 1f,
        )
        y += step
      }
    }
    content()
  }
}

@Composable
fun ArcadeTopHeader(
  title: String,
  coins: Int,
  sfxMuted: Boolean,
  bgmMuted: Boolean,
  onToggleSfx: () -> Unit,
  onToggleBgm: () -> Unit,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleLarge,
      color = TextPrimary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.weight(1f),
    )

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Surface(
        color = CosmicSurfaceElevated,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, ArcadeGold.copy(alpha = 0.55f)),
        modifier = Modifier.testTag("header_coins_pill"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.MonetizationOn,
            contentDescription = "Coins",
            tint = ArcadeGold,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(5.dp))
          Text(
            text = coins.toString(),
            style = MaterialTheme.typography.labelLarge,
            color = ArcadeGold,
          )
        }
      }

      IconButton(
        onClick = onToggleBgm,
        modifier =
          Modifier
            .minimumInteractiveComponentSize()
            .size(48.dp)
            .clip(CircleShape)
            .background(CosmicSurface.copy(alpha = 0.8f))
            .testTag("toggle_bgm_button"),
      ) {
        Icon(
          imageVector = if (bgmMuted) Icons.Filled.MusicOff else Icons.Filled.MusicNote,
          contentDescription = if (bgmMuted) "Unmute background music" else "Mute background music",
          tint = if (bgmMuted) TextSecondary else accentColor,
        )
      }

      IconButton(
        onClick = onToggleSfx,
        modifier =
          Modifier
            .minimumInteractiveComponentSize()
            .size(48.dp)
            .clip(CircleShape)
            .background(CosmicSurface.copy(alpha = 0.8f))
            .testTag("toggle_sfx_button"),
      ) {
        Icon(
          imageVector =
            if (sfxMuted) Icons.AutoMirrored.Filled.VolumeOff
            else Icons.AutoMirrored.Filled.VolumeUp,
          contentDescription = if (sfxMuted) "Unmute sound effects" else "Mute sound effects",
          tint = if (sfxMuted) TextSecondary else accentColor,
        )
      }
    }
  }
}

@Composable
fun ArcadeBottomNavBar(
  current: AppDestination,
  accentColor: Color,
  hasDailyPending: Boolean,
  onNavigate: (AppDestination) -> Unit,
  modifier: Modifier = Modifier,
) {
  val items =
    listOf(
      Triple(AppDestination.HOME, "Play", Icons.Filled.Home),
      Triple(AppDestination.LEVELS, "Levels", Icons.Filled.GridView),
      Triple(AppDestination.SHOP, "Shop", Icons.Filled.Storefront),
      Triple(AppDestination.REWARDS, "Rewards", Icons.Filled.CardGiftcard),
    )

  Surface(
    color = CosmicSurface.copy(alpha = 0.96f),
    tonalElevation = 8.dp,
    border = BorderStroke(1.dp, CosmicBorder.copy(alpha = 0.7f)),
    shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
    modifier = modifier.fillMaxWidth(),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      items.forEach { (dest, label, icon) ->
        val selected = current == dest
        NavTabItem(
          label = label,
          icon = icon,
          selected = selected,
          accentColor = accentColor,
          showBadge = dest == AppDestination.REWARDS && hasDailyPending,
          testTag = "nav_${label.lowercase()}",
          onClick = { onNavigate(dest) },
        )
      }
    }
  }
}

@Composable
private fun NavTabItem(
  label: String,
  icon: ImageVector,
  selected: Boolean,
  accentColor: Color,
  showBadge: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(14.dp))
        .background(if (selected) accentColor.copy(alpha = 0.16f) else Color.Transparent)
        .clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 6.dp)
        .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (selected) accentColor else TextSecondary,
        modifier = Modifier.size(22.dp),
      )
      if (showBadge) {
        Box(
          modifier =
            Modifier
              .size(8.dp)
              .align(Alignment.TopEnd)
              .clip(CircleShape)
              .background(ArcadeGold)
        )
      }
    }
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = if (selected) accentColor else TextSecondary,
      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
    )
  }
}

@Composable
fun ArcadePrimaryButton(
  text: String,
  onClick: () -> Unit,
  containerColor: Color,
  contentColor: Color = Color(0xFF06101B),
  icon: ImageVector? = null,
  enabled: Boolean = true,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = if (enabled) containerColor else CosmicSurfaceElevated,
    shape = RoundedCornerShape(16.dp),
    shadowElevation = if (enabled) 8.dp else 0.dp,
    modifier =
      modifier
        .height(54.dp)
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(16.dp))
        .clickable(enabled = enabled, onClick = onClick)
        .testTag(testTag),
  ) {
    Row(
      modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      if (icon != null) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (enabled) contentColor else TextSecondary,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
      }
      Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = if (enabled) contentColor else TextSecondary,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun StarRow(
  stars: Int,
  starSize: Dp = 18.dp,
  modifier: Modifier = Modifier,
) {
  Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
    for (i in 1..3) {
      Icon(
        imageVector = if (i <= stars) Icons.Filled.Star else Icons.Outlined.StarBorder,
        contentDescription = if (i <= stars) "Earned star" else "Empty star",
        tint = if (i <= stars) ArcadeGold else TextSecondary.copy(alpha = 0.45f),
        modifier = Modifier.size(starSize),
      )
    }
  }
}

@Composable
fun CharacterAvatarCanvas(
  character: RunnerCharacterSpec,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .clip(CircleShape)
        .background(character.trailColor.copy(alpha = 0.22f))
        .border(1.5.dp, character.bodyColor.copy(alpha = 0.7f), CircleShape),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
      val w = size.width
      val h = size.height
      // Character core body
      drawRoundRect(
        color = character.bodyColor,
        topLeft = Offset(w * 0.2f, h * 0.22f),
        size = Size(w * 0.6f, h * 0.58f),
        cornerRadius = CornerRadius(w * 0.22f, w * 0.22f),
      )
      // Visor / Eyes
      drawRoundRect(
        color = Color(0xFF0A081A),
        topLeft = Offset(w * 0.28f, h * 0.34f),
        size = Size(w * 0.44f, h * 0.16f),
        cornerRadius = CornerRadius(6f, 6f),
      )
      drawCircle(
        color = character.accentColor,
        radius = w * 0.055f,
        center = Offset(w * 0.39f, h * 0.42f),
      )
      drawCircle(
        color = character.accentColor,
        radius = w * 0.055f,
        center = Offset(w * 0.61f, h * 0.42f),
      )
      // Distinctive crest/ears
      val crest =
        Path().apply {
          moveTo(w * 0.3f, h * 0.24f)
          lineTo(w * 0.4f, h * 0.08f)
          lineTo(w * 0.5f, h * 0.22f)
          lineTo(w * 0.6f, h * 0.08f)
          lineTo(w * 0.7f, h * 0.24f)
          close()
        }
      drawPath(crest, color = character.accentColor.copy(alpha = 0.9f))
    }
  }
}
