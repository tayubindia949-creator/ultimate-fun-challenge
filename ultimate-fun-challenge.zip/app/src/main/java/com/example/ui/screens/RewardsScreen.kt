package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ads.RewardedAdStatus
import com.example.ads.RewardedAdUiState
import com.example.ads.UnityAdsConfig
import com.example.data.GameCatalog
import com.example.data.GameThemeSpec
import com.example.data.PlayerProgress
import com.example.ui.components.ArcadePrimaryButton
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RewardsScreen(
  progress: PlayerProgress,
  theme: GameThemeSpec,
  adUiState: RewardedAdUiState,
  currentEpochDay: Long,
  onClaimDaily: () -> Unit,
  onWatchAd: (Activity) -> Unit,
  onRetryAd: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val canClaimDaily = progress.canClaimDaily(currentEpochDay)
  val nextDayIndex = progress.nextDailyRewardIndex(currentEpochDay)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 640.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Section 1: Unity Ads Rewarded Video Vault
      item {
        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(22.dp),
          border = BorderStroke(1.5.dp, ArcadeGold.copy(alpha = 0.7f)),
          modifier = Modifier.fillMaxWidth().testTag("unity_ads_reward_card"),
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.OndemandVideo,
                  contentDescription = "Rewarded Video",
                  tint = ArcadeGold,
                  modifier = Modifier.size(28.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "Watch Ad for Coins",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                  )
                  Text(
                    text = "Earn +${UnityAdsConfig.REWARDED_COINS_AMOUNT} Coins after full video completion",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ad SDK Status Pill
            val (statusColor, statusLabel) =
              when (adUiState.status) {
                RewardedAdStatus.READY -> ElectricLime to "READY TO WATCH"
                RewardedAdStatus.INITIALIZING,
                RewardedAdStatus.LOADING -> NeonCyan to "LOADING VIDEO..."
                RewardedAdStatus.SHOWING -> ArcadeGold to "PLAYING AD..."
                RewardedAdStatus.INIT_FAILED,
                RewardedAdStatus.LOAD_FAILED -> DangerCoral to "UNAVAILABLE / OFFLINE"
                RewardedAdStatus.UNINITIALIZED -> TextSecondary to "PREPARING..."
              }

            Surface(
              color = statusColor.copy(alpha = 0.14f),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f)),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                when (adUiState.status) {
                  RewardedAdStatus.INITIALIZING,
                  RewardedAdStatus.LOADING -> {
                    CircularProgressIndicator(
                      color = statusColor,
                      strokeWidth = 2.dp,
                      modifier = Modifier.size(18.dp),
                    )
                  }
                  RewardedAdStatus.INIT_FAILED,
                  RewardedAdStatus.LOAD_FAILED -> {
                    Icon(Icons.Filled.CloudOff, contentDescription = null, tint = statusColor, modifier = Modifier.size(18.dp))
                  }
                  else -> {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = statusColor, modifier = Modifier.size(18.dp))
                  }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = statusColor,
                    modifier = Modifier.testTag("unity_ad_status_label"),
                  )
                  Text(
                    text = adUiState.statusMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            val canWatch = adUiState.status == RewardedAdStatus.READY && activity != null
            ArcadePrimaryButton(
              text =
                if (canWatch) "WATCH AD (+${UnityAdsConfig.REWARDED_COINS_AMOUNT} COINS)"
                else if (adUiState.status == RewardedAdStatus.LOADING || adUiState.status == RewardedAdStatus.INITIALIZING)
                  "LOADING REWARDED AD..."
                else "AD UNAVAILABLE",
              icon = Icons.Filled.OndemandVideo,
              containerColor = ArcadeGold,
              enabled = canWatch,
              testTag = "watch_ad_button",
              onClick = { activity?.let(onWatchAd) },
              modifier = Modifier.fillMaxWidth(),
            )

            if (adUiState.status == RewardedAdStatus.LOAD_FAILED ||
              adUiState.status == RewardedAdStatus.INIT_FAILED
            ) {
              Spacer(modifier = Modifier.height(10.dp))
              ArcadePrimaryButton(
                text = "RETRY LOADING AD",
                icon = Icons.Filled.Refresh,
                containerColor = theme.primaryAccent,
                testTag = "retry_ad_button",
                onClick = onRetryAd,
                modifier = Modifier.fillMaxWidth(),
              )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text =
                "Unity Ads Test Mode • Game ID ${UnityAdsConfig.GAME_ID} • Placement ${UnityAdsConfig.REWARDED_PLACEMENT_ID} • Ads watched: ${progress.totalAdsWatched}",
              style = MaterialTheme.typography.labelMedium,
              color = TextSecondary,
            )
          }
        }
      }

      // Section 2: 7-Day Daily Streak Rewards
      item {
        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(22.dp),
          border = BorderStroke(1.dp, theme.primaryAccent.copy(alpha = 0.55f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.CardGiftcard,
                  contentDescription = "Daily Rewards",
                  tint = theme.primaryAccent,
                  modifier = Modifier.size(26.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "7-Day Daily Streak",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                  )
                  Text(
                    text = "Current Streak: ${progress.dailyStreak} day${if (progress.dailyStreak == 1) "" else "s"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              GameCatalog.dailyRewards.chunked(4).forEach { rowDays ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  rowDays.forEach { daySpec ->
                    val dayIdx = daySpec.day - 1
                    val isClaimedInCycle =
                      if (canClaimDaily) dayIdx < nextDayIndex else dayIdx < (progress.dailyStreak % 7).let { if (it == 0 && progress.dailyStreak > 0) 7 else it }
                    val isTodayTarget = canClaimDaily && dayIdx == nextDayIndex
                    Surface(
                      color =
                        when {
                          isTodayTarget -> ArcadeGold.copy(alpha = 0.2f)
                          isClaimedInCycle -> ElectricLime.copy(alpha = 0.14f)
                          else -> CosmicSurfaceElevated
                        },
                      shape = RoundedCornerShape(14.dp),
                      border =
                        BorderStroke(
                          width = if (isTodayTarget) 1.8.dp else 1.dp,
                          color =
                            when {
                              isTodayTarget -> ArcadeGold
                              isClaimedInCycle -> ElectricLime
                              else -> CosmicBorder
                            },
                        ),
                      modifier = Modifier.weight(1f),
                    ) {
                      Column(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                      ) {
                        Text(
                          text = "D${daySpec.day}",
                          style = MaterialTheme.typography.labelMedium,
                          color = if (isTodayTarget) ArcadeGold else TextSecondary,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        if (isClaimedInCycle) {
                          Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Claimed",
                            tint = ElectricLime,
                            modifier = Modifier.size(18.dp),
                          )
                        } else {
                          Icon(
                            imageVector = Icons.Filled.MonetizationOn,
                            contentDescription = "Coins",
                            tint = ArcadeGold,
                            modifier = Modifier.size(18.dp),
                          )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                          text = "+${daySpec.coins}",
                          style = MaterialTheme.typography.labelLarge,
                          color = TextPrimary,
                          fontWeight = FontWeight.Bold,
                        )
                      }
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            val todayRewardCoins = GameCatalog.dailyRewards[nextDayIndex].coins
            ArcadePrimaryButton(
              text =
                if (canClaimDaily) "CLAIM DAY ${nextDayIndex + 1} (+$todayRewardCoins COINS)"
                else "CLAIMED FOR TODAY",
              icon = Icons.Filled.CardGiftcard,
              containerColor = theme.primaryAccent,
              enabled = canClaimDaily,
              testTag = "claim_daily_reward_button",
              onClick = onClaimDaily,
              modifier = Modifier.fillMaxWidth(),
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(12.dp)) }
    }
  }
}
