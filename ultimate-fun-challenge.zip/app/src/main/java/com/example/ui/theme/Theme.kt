package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val ArcadeColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF04101B),
    primaryContainer = Color(0xFF00485C),
    onPrimaryContainer = Color(0xFF9AF3FF),
    secondary = NeonMagenta,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF5D0F38),
    onSecondaryContainer = Color(0xFFFFD8E8),
    tertiary = ArcadeGold,
    onTertiary = Color(0xFF1D1400),
    tertiaryContainer = Color(0xFF523C00),
    onTertiaryContainer = Color(0xFFFFE082),
    background = DeepSpaceBg,
    onBackground = TextPrimary,
    surface = CosmicSurface,
    onSurface = TextPrimary,
    surfaceVariant = CosmicSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CosmicBorder,
    error = DangerCoral,
    onError = Color.White,
  )

val ArcadeShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
  )

@Composable
fun UltimateFunChallengeTheme(
  accentOverride: Color? = null,
  content: @Composable () -> Unit,
) {
  val scheme =
    if (accentOverride != null) {
      ArcadeColorScheme.copy(primary = accentOverride)
    } else {
      ArcadeColorScheme
    }
  MaterialTheme(
    colorScheme = scheme,
    typography = Typography,
    shapes = ArcadeShapes,
    content = content,
  )
}
