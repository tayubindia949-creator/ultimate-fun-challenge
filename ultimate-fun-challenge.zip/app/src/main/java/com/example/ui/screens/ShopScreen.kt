package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameCatalog
import com.example.data.GameThemeSpec
import com.example.data.PlayerProgress
import com.example.data.RunnerCharacterSpec
import com.example.ui.components.CharacterAvatarCanvas
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShopScreen(
  progress: PlayerProgress,
  theme: GameThemeSpec,
  onSelectOrBuyCharacter: (String) -> Unit,
  onSelectOrBuyTheme: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 640.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Text(
          text = "UNLOCKABLE RUNNERS",
          style = MaterialTheme.typography.titleMedium,
          color = theme.primaryAccent,
        )
      }

      items(GameCatalog.characters, key = { it.id }) { character ->
        val unlocked = character.id in progress.unlockedCharacterIds
        val equipped = character.id == progress.selectedCharacterId
        CharacterShopCard(
          character = character,
          unlocked = unlocked,
          equipped = equipped,
          canAfford = progress.coins >= character.cost,
          onClick = { onSelectOrBuyCharacter(character.id) },
        )
      }

      item {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "UNLOCKABLE ARENA THEMES",
          style = MaterialTheme.typography.titleMedium,
          color = theme.secondaryAccent,
        )
      }

      items(GameCatalog.themes, key = { it.id }) { themeItem ->
        val unlocked = themeItem.id in progress.unlockedThemeIds
        val equipped = themeItem.id == progress.selectedThemeId
        ThemeShopCard(
          themeSpec = themeItem,
          unlocked = unlocked,
          equipped = equipped,
          canAfford = progress.coins >= themeItem.cost,
          onClick = { onSelectOrBuyTheme(themeItem.id) },
        )
      }

      item { Spacer(modifier = Modifier.height(12.dp)) }
    }
  }
}

@Composable
private fun CharacterShopCard(
  character: RunnerCharacterSpec,
  unlocked: Boolean,
  equipped: Boolean,
  canAfford: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    color = if (equipped) CosmicSurfaceElevated else CosmicSurface,
    shape = RoundedCornerShape(18.dp),
    border =
      BorderStroke(
        width = if (equipped) 2.dp else 1.dp,
        color = if (equipped) ElectricLime else CosmicBorder,
      ),
    modifier =
      Modifier
        .fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onClick)
        .testTag("shop_character_${character.id}"),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      CharacterAvatarCanvas(character = character, modifier = Modifier.size(54.dp))
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(text = character.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(text = character.title, style = MaterialTheme.typography.labelMedium, color = character.bodyColor)
        Text(text = character.perkLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      }
      Spacer(modifier = Modifier.width(8.dp))
      ShopActionPill(
        unlocked = unlocked,
        equipped = equipped,
        cost = character.cost,
        canAfford = canAfford,
      )
    }
  }
}

@Composable
private fun ThemeShopCard(
  themeSpec: GameThemeSpec,
  unlocked: Boolean,
  equipped: Boolean,
  canAfford: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    color = if (equipped) CosmicSurfaceElevated else CosmicSurface,
    shape = RoundedCornerShape(18.dp),
    border =
      BorderStroke(
        width = if (equipped) 2.dp else 1.dp,
        color = if (equipped) ElectricLime else CosmicBorder,
      ),
    modifier =
      Modifier
        .fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onClick)
        .testTag("shop_theme_${themeSpec.id}"),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier
            .size(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(themeSpec.skyBottom, themeSpec.primaryAccent, themeSpec.secondaryAccent))),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Palette,
          contentDescription = themeSpec.name,
          tint = Color.White,
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(text = themeSpec.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(text = themeSpec.tagline, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      }
      Spacer(modifier = Modifier.width(8.dp))
      ShopActionPill(
        unlocked = unlocked,
        equipped = equipped,
        cost = themeSpec.cost,
        canAfford = canAfford,
      )
    }
  }
}

@Composable
private fun ShopActionPill(
  unlocked: Boolean,
  equipped: Boolean,
  cost: Int,
  canAfford: Boolean,
) {
  when {
    equipped -> {
      Row(
        modifier =
          Modifier
            .clip(RoundedCornerShape(50))
            .background(ElectricLime.copy(alpha = 0.2f))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(Icons.Filled.CheckCircle, contentDescription = "Equipped", tint = ElectricLime, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "ACTIVE", style = MaterialTheme.typography.labelMedium, color = ElectricLime)
      }
    }
    unlocked -> {
      Box(
        modifier =
          Modifier
            .clip(RoundedCornerShape(50))
            .background(CosmicSurfaceElevated)
            .padding(horizontal = 14.dp, vertical = 7.dp),
      ) {
        Text(text = "EQUIP", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
      }
    }
    else -> {
      Row(
        modifier =
          Modifier
            .clip(RoundedCornerShape(50))
            .background(if (canAfford) ArcadeGold else CosmicBorder.copy(alpha = 0.45f))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Filled.MonetizationOn,
          contentDescription = "Cost",
          tint = if (canAfford) Color(0xFF1A1200) else TextSecondary,
          modifier = Modifier.size(15.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = cost.toString(),
          style = MaterialTheme.typography.labelMedium,
          color = if (canAfford) Color(0xFF1A1200) else TextSecondary,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}
