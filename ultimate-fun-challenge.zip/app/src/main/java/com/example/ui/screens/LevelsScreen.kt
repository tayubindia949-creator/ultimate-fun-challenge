package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.GameCatalog
import com.example.data.GameThemeSpec
import com.example.data.LevelSpec
import com.example.data.PlayerProgress
import com.example.ui.components.StarRow
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.CosmicBorder
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.PlasmaViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LevelsScreen(
  progress: PlayerProgress,
  theme: GameThemeSpec,
  onSelectLevel: (Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  val worldColors = listOf(NeonCyan, NeonMagenta, ElectricLime, PlasmaViolet, ArcadeGold)
  val worlds = GameCatalog.levels.groupBy { it.worldIndex }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 640.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Surface(
          color = CosmicSurface,
          shape = RoundedCornerShape(18.dp),
          border = BorderStroke(1.dp, theme.primaryAccent.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text(
                text = "35-LEVEL ARCADE CAMPAIGN",
                style = MaterialTheme.typography.titleMedium,
                color = theme.primaryAccent,
              )
              Text(
                text = "Unlocked ${progress.highestUnlockedLevel}/35 • ${progress.totalStars}/105 Stars",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
            }
            StarRow(stars = if (progress.totalStars > 60) 3 else if (progress.totalStars > 15) 2 else 1)
          }
        }
      }

      worlds.forEach { (worldIdx, levelsInWorld) ->
        val accent = worldColors[worldIdx % worldColors.size]
        val worldName = levelsInWorld.first().worldName

        item(key = "world_$worldIdx") {
          Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier =
                Modifier
                  .size(10.dp)
                  .clip(CircleShape)
                  .background(accent)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "WORLD ${worldIdx + 1}: ${worldName.uppercase()}",
              style = MaterialTheme.typography.titleMedium,
              color = accent,
            )
          }
        }

        items(levelsInWorld, key = { it.levelNumber }) { level ->
          val unlocked = level.levelNumber <= progress.highestUnlockedLevel
          val stars = progress.levelStars[level.levelNumber] ?: 0
          val highScore = progress.levelHighScores[level.levelNumber] ?: 0
          LevelCard(
            level = level,
            unlocked = unlocked,
            stars = stars,
            highScore = highScore,
            accent = accent,
            onClick = { onSelectLevel(level.levelNumber) },
          )
        }
      }

      item { Spacer(modifier = Modifier.height(12.dp)) }
    }
  }
}

@Composable
private fun LevelCard(
  level: LevelSpec,
  unlocked: Boolean,
  stars: Int,
  highScore: Int,
  accent: Color,
  onClick: () -> Unit,
) {
  Surface(
    color = if (unlocked) CosmicSurfaceElevated else CosmicSurface.copy(alpha = 0.65f),
    shape = RoundedCornerShape(16.dp),
    border =
      BorderStroke(
        width = 1.dp,
        color = if (unlocked) accent.copy(alpha = 0.55f) else CosmicBorder.copy(alpha = 0.5f),
      ),
    modifier =
      Modifier
        .fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onClick)
        .testTag("level_card_${level.levelNumber}"),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (unlocked) accent.copy(alpha = 0.2f) else CosmicBorder.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center,
      ) {
        if (unlocked) {
          Text(
            text = level.levelNumber.toString(),
            style = MaterialTheme.typography.titleLarge,
            color = accent,
          )
        } else {
          Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = "Level ${level.levelNumber} locked",
            tint = TextSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = level.title,
          style = MaterialTheme.typography.titleMedium,
          color = if (unlocked) TextPrimary else TextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text =
            "${level.targetDistance.toInt()}m • ${level.brainGatesTarget} Brain Gate${if (level.brainGatesTarget > 1) "s" else ""} • +${level.rewardCoins} Coins",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        if (highScore > 0) {
          Text(
            text = "Best Score: $highScore",
            style = MaterialTheme.typography.labelMedium,
            color = ArcadeGold,
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Column(horizontalAlignment = Alignment.End) {
        StarRow(stars = stars, starSize = 16.dp)
        if (unlocked) {
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier =
              Modifier
                .clip(RoundedCornerShape(50))
                .background(accent)
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.PlayArrow,
              contentDescription = "Play level ${level.levelNumber}",
              tint = Color(0xFF06101B),
              modifier = Modifier.size(16.dp),
            )
            Text(
              text = "GO",
              style = MaterialTheme.typography.labelMedium,
              color = Color(0xFF06101B),
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }
  }
}
