package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ArcadeGold
import com.example.ui.theme.ElectricLime
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import kotlin.random.Random

enum class PuzzleKind(val badge: String) {
  MATH_BLITZ("MATH BLITZ"),
  PATTERN_SEQUENCE("SEQUENCE"),
  COLOR_STROOP("STROOP REFLEX"),
  ODD_ONE_OUT("LOGIC RULE"),
}

data class BrainOption(
  val label: String,
  val colorTint: Color? = null,
)

data class BrainPuzzle(
  val id: String,
  val kind: PuzzleKind,
  val question: String,
  val highlightValue: String? = null,
  val highlightColor: Color? = null,
  val options: List<BrainOption>,
  val correctIndex: Int,
  val timeLimitSec: Float,
  val bonusCoins: Int,
  val bonusScore: Int,
)

object BrainPuzzleEngine {

  fun generatePuzzle(difficulty: Int, random: Random = Random.Default): BrainPuzzle {
    val clampedDiff = difficulty.coerceIn(1, 4)
    val kind =
      when (random.nextInt(4)) {
        0 -> PuzzleKind.MATH_BLITZ
        1 -> PuzzleKind.PATTERN_SEQUENCE
        2 -> PuzzleKind.COLOR_STROOP
        else -> PuzzleKind.ODD_ONE_OUT
      }
    return when (kind) {
      PuzzleKind.MATH_BLITZ -> generateMathPuzzle(clampedDiff, random)
      PuzzleKind.PATTERN_SEQUENCE -> generateSequencePuzzle(clampedDiff, random)
      PuzzleKind.COLOR_STROOP -> generateStroopPuzzle(clampedDiff, random)
      PuzzleKind.ODD_ONE_OUT -> generateOddOneOutPuzzle(clampedDiff, random)
    }
  }

  private fun generateMathPuzzle(diff: Int, random: Random): BrainPuzzle {
    val (expr, answer) =
      when (diff) {
        1 -> {
          val a = random.nextInt(6, 25)
          val b = random.nextInt(4, 19)
          if (random.nextBoolean()) "$a + $b = ?" to (a + b) else "${a + b} - $b = ?" to a
        }
        2 -> {
          val a = random.nextInt(4, 13)
          val b = random.nextInt(3, 10)
          if (random.nextBoolean()) "$a × $b = ?" to (a * b)
          else {
            val c = random.nextInt(5, 22)
            "$a + $b + $c = ?" to (a + b + c)
          }
        }
        3 -> {
          val a = random.nextInt(5, 14)
          val b = random.nextInt(4, 12)
          val c = random.nextInt(3, 18)
          "($a × $b) + $c = ?" to (a * b + c)
        }
        else -> {
          val a = random.nextInt(6, 16)
          val b = random.nextInt(4, 13)
          val c = random.nextInt(4, 24)
          "($a × $b) - $c = ?" to (a * b - c)
        }
      }

    val distractors = mutableSetOf<Int>()
    val offsets = listOf(-10, -4, -3, -2, -1, 1, 2, 3, 4, 6, 10)
    while (distractors.size < 3) {
      val candidate = answer + offsets[random.nextInt(offsets.size)]
      if (candidate != answer && candidate >= 0) distractors.add(candidate)
    }
    val allNums = (distractors.toList() + answer).shuffled(random)
    return BrainPuzzle(
      id = "math_${random.nextInt(100000)}",
      kind = PuzzleKind.MATH_BLITZ,
      question = "Solve before the gate locks!",
      highlightValue = expr,
      highlightColor = NeonCyan,
      options = allNums.map { BrainOption(it.toString()) },
      correctIndex = allNums.indexOf(answer),
      timeLimitSec = (9.5f - diff * 0.7f).coerceAtLeast(6.5f),
      bonusCoins = 15 + diff * 5,
      bonusScore = 150 + diff * 60,
    )
  }

  private fun generateSequencePuzzle(diff: Int, random: Random): BrainPuzzle {
    val (seq, answer) =
      when (diff) {
        1 -> {
          val start = random.nextInt(2, 12)
          val step = random.nextInt(2, 8)
          listOf(start, start + step, start + step * 2, start + step * 3) to (start + step * 4)
        }
        2 -> {
          val start = random.nextInt(2, 6)
          val mult = random.nextInt(2, 4)
          listOf(start, start * mult, start * mult * mult, start * mult * mult * mult) to
            (start * mult * mult * mult * mult)
        }
        3 -> {
          val start = random.nextInt(2, 10)
          // +2, +4, +6, +8
          val n1 = start
          val n2 = n1 + 2
          val n3 = n2 + 4
          val n4 = n3 + 6
          listOf(n1, n2, n3, n4) to (n4 + 8)
        }
        else -> {
          val a = random.nextInt(2, 6)
          val b = random.nextInt(3, 8)
          val n3 = a + b
          val n4 = b + n3
          listOf(a, b, n3, n4) to (n3 + n4)
        }
      }

    val distractors = mutableSetOf<Int>()
    while (distractors.size < 3) {
      val delta = listOf(-6, -4, -2, 2, 4, 6, 8, 12).random(random)
      val c = answer + delta
      if (c != answer && c > 0) distractors.add(c)
    }
    val allNums = (distractors.toList() + answer).shuffled(random)
    return BrainPuzzle(
      id = "seq_${random.nextInt(100000)}",
      kind = PuzzleKind.PATTERN_SEQUENCE,
      question = "What number comes next?",
      highlightValue = seq.joinToString("  •  ") + "  •  ?",
      highlightColor = ArcadeGold,
      options = allNums.map { BrainOption(it.toString()) },
      correctIndex = allNums.indexOf(answer),
      timeLimitSec = (10.0f - diff * 0.6f).coerceAtLeast(7.0f),
      bonusCoins = 20 + diff * 5,
      bonusScore = 180 + diff * 65,
    )
  }

  private fun generateStroopPuzzle(diff: Int, random: Random): BrainPuzzle {
    val palette =
      listOf(
        "CYAN" to NeonCyan,
        "PINK" to NeonMagenta,
        "GOLD" to ArcadeGold,
        "LIME" to ElectricLime,
      )
    val wordPair = palette[random.nextInt(palette.size)]
    val inkOptions = palette.filter { it.first != wordPair.first }
    val inkPair = inkOptions[random.nextInt(inkOptions.size)]
    val shuffled = palette.shuffled(random)
    val correctIdx = shuffled.indexOfFirst { it.first == inkPair.first }

    return BrainPuzzle(
      id = "stroop_${random.nextInt(100000)}",
      kind = PuzzleKind.COLOR_STROOP,
      question = "Tap the INK COLOR of this word (ignore what it spells!)",
      highlightValue = wordPair.first,
      highlightColor = inkPair.second,
      options = shuffled.map { BrainOption(label = it.first, colorTint = it.second) },
      correctIndex = correctIdx,
      timeLimitSec = (8.5f - diff * 0.5f).coerceAtLeast(6.0f),
      bonusCoins = 18 + diff * 5,
      bonusScore = 175 + diff * 60,
    )
  }

  private fun generateOddOneOutPuzzle(diff: Int, random: Random): BrainPuzzle {
    val sets =
      listOf(
        Pair("Which number is NOT even?", listOf("14" to false, "28" to false, "37" to true, "42" to false)),
        Pair("Which number is NOT a multiple of 5?", listOf("15" to false, "35" to false, "42" to true, "60" to false)),
        Pair("Which expression equals a DIFFERENT value?", listOf("6 × 4" to false, "3 × 8" to false, "12 + 12" to false, "5 × 5" to true)),
        Pair("Which is a PRIME number?", listOf("9" to false, "15" to false, "17" to true, "21" to false)),
        Pair("Which expression does NOT equal 36?", listOf("6 × 6" to false, "9 × 4" to false, "18 + 18" to false, "7 × 5" to true)),
        Pair("Which number is NOT a square number?", listOf("16" to false, "25" to false, "32" to true, "49" to false)),
      )
    val chosen = sets[random.nextInt(sets.size)]
    val shuffled = chosen.second.shuffled(random)
    val correctIdx = shuffled.indexOfFirst { it.second }

    return BrainPuzzle(
      id = "odd_${random.nextInt(100000)}",
      kind = PuzzleKind.ODD_ONE_OUT,
      question = chosen.first,
      highlightValue = "SPOT THE OUTLIER",
      highlightColor = NeonMagenta,
      options = shuffled.map { BrainOption(it.first) },
      correctIndex = correctIdx,
      timeLimitSec = (9.5f - diff * 0.5f).coerceAtLeast(6.8f),
      bonusCoins = 18 + diff * 6,
      bonusScore = 170 + diff * 65,
    )
  }
}
