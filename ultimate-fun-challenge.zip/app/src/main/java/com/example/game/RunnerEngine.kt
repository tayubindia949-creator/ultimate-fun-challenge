package com.example.game

import com.example.audio.SoundEffect
import com.example.data.GameCatalog
import com.example.data.LevelSpec
import com.example.data.RunnerCharacterSpec
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

sealed interface RunMode {
  data class Campaign(val level: LevelSpec) : RunMode

  data object Endless : RunMode
}

enum class RunPhase {
  RUNNING,
  PAUSED,
  BRAIN_GATE,
  LEVEL_COMPLETE,
  GAME_OVER,
}

enum class EntityKind {
  LOW_BARRIER,
  HIGH_DRONE,
  LASER_WALL,
  SWEEPER_BOT,
  COIN,
  STAR_GEM,
  SHIELD_ORB,
  MAGNET_ORB,
  BOOST_ORB,
  BRAIN_GATE_PORTAL,
}

data class TrackEntity(
  val id: Long,
  val kind: EntityKind,
  val lane: Int,
  val z: Float, // 1.0f = horizon, 0.0f = player plane
  val sweepPhase: Float = 0f,
  val currentVisualLane: Float = lane.toFloat(),
  val collected: Boolean = false,
)

data class FloatingPopup(
  val id: Long,
  val text: String,
  val lane: Float,
  val ageSec: Float = 0f,
  val isPositive: Boolean = true,
)

data class TimedRushState(
  val active: Boolean = false,
  val coinGoal: Int = 6,
  val coinsCollected: Int = 0,
  val timeRemainingSec: Float = 0f,
  val totalTimeSec: Float = 12f,
  val rewardCoins: Int = 35,
)

data class GameRunState(
  val mode: RunMode,
  val character: RunnerCharacterSpec,
  val phase: RunPhase = RunPhase.RUNNING,
  val targetLane: Int = 1,
  val visualLane: Float = 1f,
  val jumpHeight: Float = 0f,
  val jumpVelocity: Float = 0f,
  val slideTimer: Float = 0f,
  val lives: Int = 3,
  val maxLives: Int = 3,
  val hasShield: Boolean = character.startingShield,
  val magnetTimer: Float = 0f,
  val boostTimer: Float = 0f,
  val invincibleTimer: Float = 0f,
  val shakeTimer: Float = 0f,
  val score: Int = 0,
  val coinsCollected: Int = 0,
  val combo: Int = 1,
  val maxCombo: Int = 1,
  val distance: Float = 0f,
  val elapsedSec: Float = 0f,
  val speed: Float = 360f,
  val trackScrollOffset: Float = 0f,
  val entities: List<TrackEntity> = emptyList(),
  val popups: List<FloatingPopup> = emptyList(),
  val activeBrainPuzzle: BrainPuzzle? = null,
  val brainPuzzleTimeLeft: Float = 0f,
  val brainGatesSolved: Int = 0,
  val brainGatesAttempted: Int = 0,
  val timedRush: TimedRushState = TimedRushState(),
  val earnedStars: Int = 0,
  val completionBonusCoins: Int = 0,
) {
  val progressFraction: Float
    get() =
      when (mode) {
        is RunMode.Campaign -> (distance / mode.level.targetDistance).coerceIn(0f, 1f)
        RunMode.Endless -> ((distance % 1000f) / 1000f)
      }
}

data class EngineStepResult(
  val state: GameRunState,
  val events: List<SoundEffect> = emptyList(),
)

class RunnerEngine(private val random: Random = Random.Default) {
  private var nextEntityId = 1L
  private var nextPopupId = 1L
  private var spawnTimer = 0.4f
  private var nextBrainGateDistance = 220f
  private var nextRushDistance = 110f

  fun createInitialState(mode: RunMode, character: RunnerCharacterSpec): GameRunState {
    nextEntityId = 1L
    nextPopupId = 1L
    spawnTimer = 0.35f

    val baseSpeed =
      when (mode) {
        is RunMode.Campaign -> mode.level.baseSpeed
        RunMode.Endless -> 370f
      }
    nextBrainGateDistance =
      when (mode) {
        is RunMode.Campaign ->
          mode.level.targetDistance / (mode.level.brainGatesTarget + 1).toFloat()
        RunMode.Endless -> 320f
      }
    nextRushDistance = 95f

    return GameRunState(
      mode = mode,
      character = character,
      speed = baseSpeed,
      hasShield = character.startingShield,
    )
  }

  fun moveLeft(state: GameRunState): EngineStepResult {
    if (state.phase != RunPhase.RUNNING) return EngineStepResult(state)
    val nextLane = (state.targetLane - 1).coerceAtLeast(0)
    return if (nextLane != state.targetLane) {
      EngineStepResult(state.copy(targetLane = nextLane), listOf(SoundEffect.LANE_SWAP))
    } else {
      EngineStepResult(state)
    }
  }

  fun moveRight(state: GameRunState): EngineStepResult {
    if (state.phase != RunPhase.RUNNING) return EngineStepResult(state)
    val nextLane = (state.targetLane + 1).coerceAtMost(2)
    return if (nextLane != state.targetLane) {
      EngineStepResult(state.copy(targetLane = nextLane), listOf(SoundEffect.LANE_SWAP))
    } else {
      EngineStepResult(state)
    }
  }

  fun jump(state: GameRunState): EngineStepResult {
    if (state.phase != RunPhase.RUNNING) return EngineStepResult(state)
    if (state.jumpHeight <= 0.02f && state.jumpVelocity <= 0f) {
      return EngineStepResult(
        state.copy(jumpVelocity = 4.2f, slideTimer = 0f),
        listOf(SoundEffect.JUMP),
      )
    }
    return EngineStepResult(state)
  }

  fun slide(state: GameRunState): EngineStepResult {
    if (state.phase != RunPhase.RUNNING) return EngineStepResult(state)
    // Fast drop if mid-air, otherwise trigger slide duck
    return if (state.jumpHeight > 0.05f) {
      EngineStepResult(state.copy(jumpVelocity = -7.5f, slideTimer = 0.55f), listOf(SoundEffect.LANE_SWAP))
    } else {
      EngineStepResult(state.copy(slideTimer = 0.72f), listOf(SoundEffect.LANE_SWAP))
    }
  }

  fun togglePause(state: GameRunState): GameRunState =
    when (state.phase) {
      RunPhase.RUNNING -> state.copy(phase = RunPhase.PAUSED)
      RunPhase.PAUSED -> state.copy(phase = RunPhase.RUNNING)
      else -> state
    }

  fun answerBrainPuzzle(state: GameRunState, optionIndex: Int): EngineStepResult {
    val puzzle = state.activeBrainPuzzle ?: return EngineStepResult(state)
    if (state.phase != RunPhase.BRAIN_GATE) return EngineStepResult(state)

    val isCorrect = optionIndex == puzzle.correctIndex
    return resolveBrainGate(state, puzzle, isCorrect, timedOut = false)
  }

  fun step(state: GameRunState, deltaSec: Float): EngineStepResult {
    val dt = deltaSec.coerceIn(0.001f, 0.05f)
    val events = mutableListOf<SoundEffect>()

    if (state.phase == RunPhase.BRAIN_GATE) {
      val puzzle = state.activeBrainPuzzle ?: return EngineStepResult(state.copy(phase = RunPhase.RUNNING))
      val newTime = state.brainPuzzleTimeLeft - dt
      if (newTime <= 0f) {
        return resolveBrainGate(state, puzzle, isCorrect = false, timedOut = true)
      }
      return EngineStepResult(state.copy(brainPuzzleTimeLeft = newTime))
    }

    if (state.phase != RunPhase.RUNNING) {
      return EngineStepResult(state)
    }

    var lives = state.lives
    var hasShield = state.hasShield
    var magnetTimer = max(0f, state.magnetTimer - dt)
    var boostTimer = max(0f, state.boostTimer - dt)
    var invincibleTimer = max(0f, state.invincibleTimer - dt)
    var shakeTimer = max(0f, state.shakeTimer - dt)
    var slideTimer = max(0f, state.slideTimer - dt)
    var combo = state.combo
    var maxCombo = state.maxCombo
    var score = state.score
    var coinsCollected = state.coinsCollected
    val popups = state.popups.mapNotNull {
      val aged = it.copy(ageSec = it.ageSec + dt)
      if (aged.ageSec < 1.1f) aged else null
    }.toMutableList()

    // Physics: lane interpolation & jump arc
    val laneDiff = state.targetLane.toFloat() - state.visualLane
    val newVisualLane = state.visualLane + laneDiff * min(1f, dt * 16f)

    var jumpH = state.jumpHeight
    var jumpV = state.jumpVelocity
    if (jumpH > 0f || jumpV != 0f) {
      jumpH += jumpV * dt
      jumpV -= 12.5f * dt
      if (jumpH <= 0f) {
        jumpH = 0f
        jumpV = 0f
      }
    }

    // Speed progression
    val baseSpeed =
      when (val m = state.mode) {
        is RunMode.Campaign -> m.level.baseSpeed + (state.distance * 0.06f)
        RunMode.Endless -> 370f + (state.elapsedSec * 6.5f).coerceAtMost(460f)
      }
    val effectiveSpeed = if (boostTimer > 0f) baseSpeed * 1.48f else baseSpeed
    val distanceDelta = (effectiveSpeed * dt) * 0.22f
    val newDistance = state.distance + distanceDelta
    val scoreGain = (distanceDelta * (if (boostTimer > 0f) 2 else 1) * combo).toInt().coerceAtLeast(1)
    score += scoreGain

    val scrollOffset = (state.trackScrollOffset + (effectiveSpeed / 520f) * dt) % 1f

    // Timed Rush Challenge management
    var rush = state.timedRush
    if (rush.active) {
      val rem = rush.timeRemainingSec - dt
      if (rush.coinsCollected >= rush.coinGoal) {
        coinsCollected += rush.rewardCoins
        score += rush.rewardCoins * 10
        popups.add(
          FloatingPopup(
            id = nextPopupId++,
            text = "RUSH WIN +${rush.rewardCoins}!",
            lane = 1f,
            isPositive = true,
          )
        )
        events.add(SoundEffect.POWER_UP)
        rush = rush.copy(active = false)
        nextRushDistance = newDistance + 360f
      } else if (rem <= 0f) {
        popups.add(FloatingPopup(id = nextPopupId++, text = "RUSH ENDED", lane = 1f, isPositive = false))
        rush = rush.copy(active = false)
        nextRushDistance = newDistance + 320f
      } else {
        rush = rush.copy(timeRemainingSec = rem)
      }
    } else if (newDistance >= nextRushDistance) {
      val (goal, secs, reward) =
        when (val m = state.mode) {
          is RunMode.Campaign -> Triple(m.level.timedRushCoinGoal, m.level.timedRushSeconds.toFloat(), 30 + m.level.levelNumber * 2)
          RunMode.Endless -> Triple(7 + (state.elapsedSec / 25f).toInt().coerceAtMost(8), 11f, 45)
        }
      rush =
        TimedRushState(
          active = true,
          coinGoal = goal,
          coinsCollected = 0,
          timeRemainingSec = secs,
          totalTimeSec = secs,
          rewardCoins = reward,
        )
      popups.add(FloatingPopup(id = nextPopupId++, text = "COIN RUSH: $goal!", lane = 1f, isPositive = true))
    }

    // Move existing entities toward player (z: 1.0f -> 0.0f)
    val zSpeed = effectiveSpeed / 640f
    val updatedEntities = mutableListOf<TrackEntity>()
    var triggeredBrainGate = false

    for (entity in state.entities) {
      if (entity.collected) continue
      val nextZ = entity.z - zSpeed * dt
      if (nextZ < -0.10f) continue

      var currentLaneFloat = entity.currentVisualLane
      if (entity.kind == EntityKind.SWEEPER_BOT) {
        val nextPhase = entity.sweepPhase + dt * 3.1f
        currentLaneFloat = 1f + sin(nextPhase) * 1.0f
      }

      // Magnet pulls coins toward player lane
      var updatedLaneFloat = currentLaneFloat
      if (magnetTimer > 0f &&
        (entity.kind == EntityKind.COIN || entity.kind == EntityKind.STAR_GEM) &&
        nextZ < 0.45f
      ) {
        updatedLaneFloat = currentLaneFloat + (newVisualLane - currentLaneFloat) * min(1f, dt * 10f)
      }

      val updatedEntity =
        entity.copy(
          z = nextZ,
          sweepPhase = if (entity.kind == EntityKind.SWEEPER_BOT) entity.sweepPhase + dt * 3.1f else entity.sweepPhase,
          currentVisualLane = updatedLaneFloat,
        )

      // Collision detection in player depth band
      if (nextZ in 0.02f..0.14f) {
        if (entity.kind == EntityKind.BRAIN_GATE_PORTAL) {
          triggeredBrainGate = true
          continue
        }

        val laneClose = abs(newVisualLane - updatedLaneFloat) < 0.43f
        if (laneClose) {
          when (entity.kind) {
            EntityKind.COIN -> {
              val bonus = if (random.nextFloat() < state.character.bonusCoinChance) 2 else 1
              coinsCollected += bonus
              score += 25 * combo
              combo = (combo + 1).coerceAtMost(8)
              maxCombo = max(maxCombo, combo)
              if (rush.active) rush = rush.copy(coinsCollected = rush.coinsCollected + 1)
              popups.add(
                FloatingPopup(
                  id = nextPopupId++,
                  text = if (bonus > 1) "+$bonus COINS!" else "+1",
                  lane = newVisualLane,
                  isPositive = true,
                )
              )
              events.add(SoundEffect.COIN)
              continue
            }
            EntityKind.STAR_GEM -> {
              coinsCollected += 5
              score += 110 * combo
              combo = (combo + 1).coerceAtMost(8)
              maxCombo = max(maxCombo, combo)
              if (rush.active) rush = rush.copy(coinsCollected = rush.coinsCollected + 2)
              popups.add(FloatingPopup(id = nextPopupId++, text = "+5 GEM!", lane = newVisualLane, isPositive = true))
              events.add(SoundEffect.GEM)
              continue
            }
            EntityKind.SHIELD_ORB -> {
              hasShield = true
              popups.add(FloatingPopup(id = nextPopupId++, text = "SHIELD ON!", lane = newVisualLane, isPositive = true))
              events.add(SoundEffect.POWER_UP)
              continue
            }
            EntityKind.MAGNET_ORB -> {
              magnetTimer = 6.5f
              popups.add(FloatingPopup(id = nextPopupId++, text = "MAGNET!", lane = newVisualLane, isPositive = true))
              events.add(SoundEffect.POWER_UP)
              continue
            }
            EntityKind.BOOST_ORB -> {
              boostTimer = 3.2f
              popups.add(FloatingPopup(id = nextPopupId++, text = "TURBO x2!", lane = newVisualLane, isPositive = true))
              events.add(SoundEffect.POWER_UP)
              continue
            }
            EntityKind.LOW_BARRIER,
            EntityKind.HIGH_DRONE,
            EntityKind.LASER_WALL,
            EntityKind.SWEEPER_BOT -> {
              val dodgedByJump = entity.kind == EntityKind.LOW_BARRIER && jumpH >= 0.42f
              val dodgedBySlide = entity.kind == EntityKind.HIGH_DRONE && slideTimer > 0f
              if (!dodgedByJump && !dodgedBySlide && boostTimer <= 0f && invincibleTimer <= 0f) {
                if (hasShield) {
                  hasShield = false
                  invincibleTimer = 1.1f
                  shakeTimer = 0.22f
                  popups.add(FloatingPopup(id = nextPopupId++, text = "SHIELD SAVED!", lane = newVisualLane, isPositive = true))
                  events.add(SoundEffect.POWER_UP)
                } else {
                  lives -= 1
                  combo = 1
                  invincibleTimer = 1.35f
                  shakeTimer = 0.35f
                  popups.add(FloatingPopup(id = nextPopupId++, text = "-1 LIFE!", lane = newVisualLane, isPositive = false))
                  events.add(SoundEffect.HIT)
                }
                continue
              }
            }
            EntityKind.BRAIN_GATE_PORTAL -> Unit
          }
        }
      }

      updatedEntities.add(updatedEntity)
    }

    // Spawn Brain Gate or Obstacles/Coins
    val canSpawnBrainGate =
      when (val m = state.mode) {
        is RunMode.Campaign -> state.brainGatesAttempted < m.level.brainGatesTarget && newDistance >= nextBrainGateDistance
        RunMode.Endless -> newDistance >= nextBrainGateDistance
      }

    if (canSpawnBrainGate && updatedEntities.none { it.kind == EntityKind.BRAIN_GATE_PORTAL }) {
      updatedEntities.add(
        TrackEntity(
          id = nextEntityId++,
          kind = EntityKind.BRAIN_GATE_PORTAL,
          lane = 1,
          z = 1.0f,
        )
      )
      nextBrainGateDistance =
        when (val m = state.mode) {
          is RunMode.Campaign ->
            newDistance + (m.level.targetDistance / (m.level.brainGatesTarget + 1f))
          RunMode.Endless -> newDistance + 360f
        }
    }

    spawnTimer -= dt
    if (spawnTimer <= 0f) {
      val interval =
        when (val m = state.mode) {
          is RunMode.Campaign -> m.level.obstacleSpawnIntervalSec
          RunMode.Endless -> max(0.42f, 0.96f - state.elapsedSec * 0.005f)
        }
      spawnTimer = interval * (0.85f + random.nextFloat() * 0.35f)
      spawnWave(updatedEntities, state.mode)
    }

    // Check Game Over
    if (lives <= 0) {
      events.add(SoundEffect.GAME_OVER)
      return EngineStepResult(
        state.copy(
          phase = RunPhase.GAME_OVER,
          lives = 0,
          visualLane = newVisualLane,
          jumpHeight = jumpH,
          jumpVelocity = jumpV,
          slideTimer = slideTimer,
          hasShield = hasShield,
          magnetTimer = magnetTimer,
          boostTimer = boostTimer,
          invincibleTimer = invincibleTimer,
          shakeTimer = shakeTimer,
          score = score,
          coinsCollected = coinsCollected,
          combo = combo,
          maxCombo = maxCombo,
          distance = newDistance,
          elapsedSec = state.elapsedSec + dt,
          speed = effectiveSpeed,
          trackScrollOffset = scrollOffset,
          entities = updatedEntities,
          popups = popups,
          timedRush = rush,
        ),
        events,
      )
    }

    // Check Brain Gate trigger
    if (triggeredBrainGate) {
      val diff =
        when (val m = state.mode) {
          is RunMode.Campaign -> m.level.puzzleDifficulty
          RunMode.Endless -> (1 + (state.elapsedSec / 30f).toInt()).coerceIn(1, 4)
        }
      val puzzle = BrainPuzzleEngine.generatePuzzle(diff, random)
      events.add(SoundEffect.POWER_UP)
      return EngineStepResult(
        state.copy(
          phase = RunPhase.BRAIN_GATE,
          visualLane = newVisualLane,
          jumpHeight = jumpH,
          jumpVelocity = jumpV,
          slideTimer = slideTimer,
          lives = lives,
          hasShield = hasShield,
          magnetTimer = magnetTimer,
          boostTimer = boostTimer,
          invincibleTimer = invincibleTimer,
          shakeTimer = shakeTimer,
          score = score,
          coinsCollected = coinsCollected,
          combo = combo,
          maxCombo = maxCombo,
          distance = newDistance,
          elapsedSec = state.elapsedSec + dt,
          speed = effectiveSpeed,
          trackScrollOffset = scrollOffset,
          entities = updatedEntities,
          popups = popups,
          activeBrainPuzzle = puzzle,
          brainPuzzleTimeLeft = puzzle.timeLimitSec,
          brainGatesAttempted = state.brainGatesAttempted + 1,
          timedRush = rush,
        ),
        events,
      )
    }

    // Check Campaign Level Completion
    if (state.mode is RunMode.Campaign && newDistance >= state.mode.level.targetDistance) {
      val lvl = state.mode.level
      val finalScore = score + lives * 120 + coinsCollected * 15
      val stars =
        when {
          finalScore >= lvl.star3Score -> 3
          finalScore >= lvl.star2Score -> 2
          else -> 1
        }
      val totalBonus = lvl.rewardCoins + stars * 15
      events.add(SoundEffect.LEVEL_COMPLETE)
      return EngineStepResult(
        state.copy(
          phase = RunPhase.LEVEL_COMPLETE,
          visualLane = newVisualLane,
          jumpHeight = 0f,
          jumpVelocity = 0f,
          slideTimer = 0f,
          lives = lives,
          hasShield = hasShield,
          score = finalScore,
          coinsCollected = coinsCollected,
          combo = combo,
          maxCombo = maxCombo,
          distance = lvl.targetDistance,
          elapsedSec = state.elapsedSec + dt,
          speed = effectiveSpeed,
          trackScrollOffset = scrollOffset,
          entities = emptyList(),
          popups = popups,
          timedRush = rush,
          earnedStars = stars,
          completionBonusCoins = totalBonus,
        ),
        events,
      )
    }

    return EngineStepResult(
      state.copy(
        visualLane = newVisualLane,
        jumpHeight = jumpH,
        jumpVelocity = jumpV,
        slideTimer = slideTimer,
        lives = lives,
        hasShield = hasShield,
        magnetTimer = magnetTimer,
        boostTimer = boostTimer,
        invincibleTimer = invincibleTimer,
        shakeTimer = shakeTimer,
        score = score,
        coinsCollected = coinsCollected,
        combo = combo,
        maxCombo = maxCombo,
        distance = newDistance,
        elapsedSec = state.elapsedSec + dt,
        speed = effectiveSpeed,
        trackScrollOffset = scrollOffset,
        entities = updatedEntities,
        popups = popups,
        timedRush = rush,
      ),
      events,
    )
  }

  private fun resolveBrainGate(
    state: GameRunState,
    puzzle: BrainPuzzle,
    isCorrect: Boolean,
    timedOut: Boolean,
  ): EngineStepResult {
    val popups = state.popups.toMutableList()
    return if (isCorrect) {
      val newCoins = state.coinsCollected + puzzle.bonusCoins
      val newScore = state.score + puzzle.bonusScore
      popups.add(
        FloatingPopup(
          id = nextPopupId++,
          text = "BRAIN BOOST +${puzzle.bonusCoins}!",
          lane = 1f,
          isPositive = true,
        )
      )
      EngineStepResult(
        state.copy(
          phase = RunPhase.RUNNING,
          activeBrainPuzzle = null,
          brainPuzzleTimeLeft = 0f,
          brainGatesSolved = state.brainGatesSolved + 1,
          coinsCollected = newCoins,
          score = newScore,
          hasShield = true,
          invincibleTimer = 1.0f,
          popups = popups,
        ),
        listOf(SoundEffect.BRAIN_CORRECT),
      )
    } else {
      val newLives = (state.lives - 1).coerceAtLeast(0)
      val nextPhase = if (newLives <= 0) RunPhase.GAME_OVER else RunPhase.RUNNING
      popups.add(
        FloatingPopup(
          id = nextPopupId++,
          text = if (timedOut) "TIME UP! -1 LIFE" else "WRONG! -1 LIFE",
          lane = 1f,
          isPositive = false,
        )
      )
      val events =
        if (nextPhase == RunPhase.GAME_OVER) {
          listOf(SoundEffect.BRAIN_WRONG, SoundEffect.GAME_OVER)
        } else {
          listOf(SoundEffect.BRAIN_WRONG)
        }
      EngineStepResult(
        state.copy(
          phase = nextPhase,
          lives = newLives,
          combo = 1,
          invincibleTimer = 1.2f,
          shakeTimer = 0.25f,
          activeBrainPuzzle = null,
          brainPuzzleTimeLeft = 0f,
          popups = popups,
        ),
        events,
      )
    }
  }

  private fun spawnWave(entities: MutableList<TrackEntity>, mode: RunMode) {
    val allowLaser =
      when (mode) {
        is RunMode.Campaign -> mode.level.hasLaserWalls
        RunMode.Endless -> true
      }
    val allowSweeper =
      when (mode) {
        is RunMode.Campaign -> mode.level.hasSweeperBots
        RunMode.Endless -> true
      }

    val safeLane = random.nextInt(3)
    val roll = random.nextFloat()

    // Always keep at least one safe/collectible lane!
    when {
      roll < 0.22f -> {
        // Pure coin line in a random lane + occasional gem
        val lane = random.nextInt(3)
        entities.add(TrackEntity(nextEntityId++, EntityKind.COIN, lane, 1.0f))
        entities.add(TrackEntity(nextEntityId++, EntityKind.COIN, lane, 1.08f))
        if (random.nextFloat() < 0.35f) {
          entities.add(TrackEntity(nextEntityId++, EntityKind.STAR_GEM, lane, 1.16f))
        }
      }
      roll < 0.30f -> {
        // Power-up orb + coin
        val powerKind =
          when (random.nextInt(3)) {
            0 -> EntityKind.SHIELD_ORB
            1 -> EntityKind.MAGNET_ORB
            else -> EntityKind.BOOST_ORB
          }
        entities.add(TrackEntity(nextEntityId++, powerKind, safeLane, 1.0f))
        val coinLane = (safeLane + 1) % 3
        entities.add(TrackEntity(nextEntityId++, EntityKind.COIN, coinLane, 1.0f))
      }
      roll < 0.56f -> {
        // 1 obstacle + coin trail in safe lane
        val obsLane = (safeLane + random.nextInt(1, 3)) % 3
        val kind = pickObstacleKind(allowLaser, allowSweeper)
        entities.add(TrackEntity(nextEntityId++, kind, obsLane, 1.0f))
        entities.add(TrackEntity(nextEntityId++, EntityKind.COIN, safeLane, 1.0f))
      }
      else -> {
        // 2 obstacles leaving safeLane open (or jumpable/slideable) + gem/coin reward in safeLane
        for (lane in 0..2) {
          if (lane == safeLane) {
            val reward = if (random.nextFloat() < 0.22f) EntityKind.STAR_GEM else EntityKind.COIN
            entities.add(TrackEntity(nextEntityId++, reward, lane, 1.0f))
          } else {
            val kind = pickObstacleKind(allowLaser, allowSweeper = false)
            entities.add(TrackEntity(nextEntityId++, kind, lane, 1.0f))
          }
        }
      }
    }
  }

  private fun pickObstacleKind(allowLaser: Boolean, allowSweeper: Boolean): EntityKind {
    val pool = mutableListOf(EntityKind.LOW_BARRIER, EntityKind.HIGH_DRONE)
    if (allowLaser) pool.add(EntityKind.LASER_WALL)
    if (allowSweeper) pool.add(EntityKind.SWEEPER_BOT)
    return pool[random.nextInt(pool.size)]
  }
}
