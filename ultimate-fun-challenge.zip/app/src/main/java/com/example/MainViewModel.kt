package com.example

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ads.RewardedAdController
import com.example.ads.RewardedAdUiState
import com.example.audio.ArcadeSoundEngine
import com.example.audio.SoundEffect
import com.example.data.GameCatalog
import com.example.data.GameSaveRepository
import com.example.data.PlayerProgress
import com.example.game.BrainPuzzle
import com.example.game.BrainPuzzleEngine
import com.example.game.GameRunState
import com.example.game.RunMode
import com.example.game.RunPhase
import com.example.game.RunnerEngine
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppDestination {
  HOME,
  LEVELS,
  GAMEPLAY,
  BRAIN_BLITZ,
  SHOP,
  REWARDS,
}

data class BrainBlitzState(
  val active: Boolean = false,
  val finished: Boolean = false,
  val round: Int = 1,
  val totalRounds: Int = 8,
  val score: Int = 0,
  val coinsEarned: Int = 0,
  val streak: Int = 0,
  val correctCount: Int = 0,
  val puzzle: BrainPuzzle? = null,
  val timeLeftSec: Float = 0f,
  val lastFeedback: String? = null,
)

class MainViewModel(
  private val saveRepository: GameSaveRepository,
  val adController: RewardedAdController,
  val soundEngine: ArcadeSoundEngine,
  private val epochDayProvider: () -> Long = { TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis()) },
) : ViewModel() {

  val progress: StateFlow<PlayerProgress> = saveRepository.progress
  val adUiState: StateFlow<RewardedAdUiState> = adController.uiState

  private val _destination = MutableStateFlow(AppDestination.HOME)
  val destination: StateFlow<AppDestination> = _destination.asStateFlow()

  private val _runState = MutableStateFlow<GameRunState?>(null)
  val runState: StateFlow<GameRunState?> = _runState.asStateFlow()

  private val _brainBlitz = MutableStateFlow(BrainBlitzState())
  val brainBlitz: StateFlow<BrainBlitzState> = _brainBlitz.asStateFlow()

  private val _bannerMessage = MutableStateFlow<String?>(null)
  val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

  private val runnerEngine = RunnerEngine()
  private var gameLoopJob: Job? = null
  private var brainBlitzLoopJob: Job? = null
  private var runResultsPersisted = false

  init {
    viewModelScope.launch {
      saveRepository.ensureLoaded()
      saveRepository.progress.collectLatest { p ->
        soundEngine.sfxMuted = p.sfxMuted
        soundEngine.bgmMuted = p.bgmMuted
      }
    }
  }

  fun initializeAds(context: Context) {
    adController.initialize(context)
  }

  fun navigateTo(dest: AppDestination) {
    soundEngine.playSfx(SoundEffect.TAP)
    if (dest != AppDestination.GAMEPLAY) {
      stopGameLoop()
    }
    if (dest != AppDestination.BRAIN_BLITZ) {
      brainBlitzLoopJob?.cancel()
    }
    _destination.value = dest
  }

  fun navigateBack() {
    when (_destination.value) {
      AppDestination.GAMEPLAY -> {
        val current = _runState.value
        if (current != null && current.phase == RunPhase.RUNNING) {
          togglePauseRun()
        } else {
          stopGameLoop()
          _runState.value = null
          _destination.value = AppDestination.HOME
        }
      }
      AppDestination.BRAIN_BLITZ -> {
        brainBlitzLoopJob?.cancel()
        _destination.value = AppDestination.HOME
      }
      AppDestination.LEVELS,
      AppDestination.SHOP,
      AppDestination.REWARDS -> _destination.value = AppDestination.HOME
      AppDestination.HOME -> Unit
    }
  }

  fun clearBannerMessage() {
    _bannerMessage.value = null
  }

  // --- Campaign & Endless Runner ---

  fun startCampaignLevel(levelNumber: Int) {
    val unlocked = progress.value.highestUnlockedLevel
    if (levelNumber > unlocked) {
      _bannerMessage.value = "Complete Level ${levelNumber - 1} first to unlock Level $levelNumber!"
      return
    }
    val level = GameCatalog.getLevel(levelNumber)
    val character = GameCatalog.getCharacter(progress.value.selectedCharacterId)
    runResultsPersisted = false
    _runState.value = runnerEngine.createInitialState(RunMode.Campaign(level), character)
    _destination.value = AppDestination.GAMEPLAY
    soundEngine.playSfx(SoundEffect.TAP)
    startGameLoop()
  }

  fun startEndlessRun() {
    val character = GameCatalog.getCharacter(progress.value.selectedCharacterId)
    runResultsPersisted = false
    _runState.value = runnerEngine.createInitialState(RunMode.Endless, character)
    _destination.value = AppDestination.GAMEPLAY
    soundEngine.playSfx(SoundEffect.TAP)
    startGameLoop()
  }

  fun restartRun() {
    val current = _runState.value ?: return
    val character = GameCatalog.getCharacter(progress.value.selectedCharacterId)
    runResultsPersisted = false
    _runState.value = runnerEngine.createInitialState(current.mode, character)
    soundEngine.playSfx(SoundEffect.TAP)
    startGameLoop()
  }

  fun togglePauseRun() {
    val current = _runState.value ?: return
    val next = runnerEngine.togglePause(current)
    _runState.value = next
    soundEngine.playSfx(SoundEffect.TAP)
  }

  fun pauseRunIfActive() {
    val current = _runState.value ?: return
    if (current.phase == RunPhase.RUNNING) {
      _runState.value = current.copy(phase = RunPhase.PAUSED)
    }
  }

  fun onMoveLeft() {
    val current = _runState.value ?: return
    val result = runnerEngine.moveLeft(current)
    _runState.value = result.state
    result.events.forEach { soundEngine.playSfx(it) }
  }

  fun onMoveRight() {
    val current = _runState.value ?: return
    val result = runnerEngine.moveRight(current)
    _runState.value = result.state
    result.events.forEach { soundEngine.playSfx(it) }
  }

  fun onJump() {
    val current = _runState.value ?: return
    val result = runnerEngine.jump(current)
    _runState.value = result.state
    result.events.forEach { soundEngine.playSfx(it) }
  }

  fun onSlide() {
    val current = _runState.value ?: return
    val result = runnerEngine.slide(current)
    _runState.value = result.state
    result.events.forEach { soundEngine.playSfx(it) }
  }

  fun onAnswerRunBrainPuzzle(optionIndex: Int) {
    val current = _runState.value ?: return
    val result = runnerEngine.answerBrainPuzzle(current, optionIndex)
    _runState.value = result.state
    result.events.forEach { soundEngine.playSfx(it) }
    if (result.state.phase == RunPhase.GAME_OVER) {
      persistFinishedRun(result.state)
    }
  }

  private fun startGameLoop() {
    gameLoopJob?.cancel()
    gameLoopJob =
      viewModelScope.launch {
        var lastTimeNanos = System.nanoTime()
        while (isActive) {
          delay(16L)
          val now = System.nanoTime()
          val dt = ((now - lastTimeNanos) / 1_000_000_000f).coerceIn(0.004f, 0.045f)
          lastTimeNanos = now

          val current = _runState.value ?: break
          if (current.phase == RunPhase.RUNNING || current.phase == RunPhase.BRAIN_GATE) {
            val result = runnerEngine.step(current, dt)
            _runState.value = result.state
            result.events.forEach { soundEngine.playSfx(it) }
            if (result.state.phase == RunPhase.LEVEL_COMPLETE ||
              result.state.phase == RunPhase.GAME_OVER
            ) {
              persistFinishedRun(result.state)
            }
          }
        }
      }
  }

  private fun stopGameLoop() {
    gameLoopJob?.cancel()
    gameLoopJob = null
  }

  private fun persistFinishedRun(finalState: GameRunState) {
    if (runResultsPersisted) return
    runResultsPersisted = true

    val totalEarnedCoins =
      finalState.coinsCollected +
        if (finalState.phase == RunPhase.LEVEL_COMPLETE) finalState.completionBonusCoins else 0

    viewModelScope.launch {
      saveRepository.updateProgress { p ->
        val updatedScores = p.levelHighScores.toMutableMap()
        val updatedStars = p.levelStars.toMutableMap()
        var nextUnlocked = p.highestUnlockedLevel
        var endlessBest = p.endlessHighScore

        when (val m = finalState.mode) {
          is RunMode.Campaign -> {
            val lvlNum = m.level.levelNumber
            val prevScore = updatedScores[lvlNum] ?: 0
            if (finalState.score > prevScore) {
              updatedScores[lvlNum] = finalState.score
            }
            if (finalState.phase == RunPhase.LEVEL_COMPLETE) {
              val prevStars = updatedStars[lvlNum] ?: 0
              if (finalState.earnedStars > prevStars) {
                updatedStars[lvlNum] = finalState.earnedStars
              }
              if (lvlNum >= nextUnlocked && lvlNum < 35) {
                nextUnlocked = lvlNum + 1
              }
            }
          }
          RunMode.Endless -> {
            if (finalState.score > endlessBest) {
              endlessBest = finalState.score
            }
          }
        }

        p.copy(
          coins = p.coins + totalEarnedCoins,
          highestUnlockedLevel = nextUnlocked,
          levelHighScores = updatedScores,
          levelStars = updatedStars,
          endlessHighScore = endlessBest,
          totalHighScore = maxOf(p.totalHighScore, finalState.score),
          totalRunsCompleted = p.totalRunsCompleted + 1,
        )
      }
    }
  }

  // --- Brain Blitz Standalone Mode ---

  fun startBrainBlitz() {
    soundEngine.playSfx(SoundEffect.TAP)
    val firstPuzzle = BrainPuzzleEngine.generatePuzzle(difficulty = 1)
    _brainBlitz.value =
      BrainBlitzState(
        active = true,
        finished = false,
        round = 1,
        totalRounds = 8,
        score = 0,
        coinsEarned = 0,
        streak = 0,
        correctCount = 0,
        puzzle = firstPuzzle,
        timeLeftSec = firstPuzzle.timeLimitSec,
        lastFeedback = null,
      )
    _destination.value = AppDestination.BRAIN_BLITZ
    startBrainBlitzTimer()
  }

  fun answerBrainBlitz(optionIndex: Int) {
    val cur = _brainBlitz.value
    val puzzle = cur.puzzle ?: return
    if (!cur.active || cur.finished) return

    val isCorrect = optionIndex == puzzle.correctIndex
    resolveBrainBlitzRound(cur, puzzle, isCorrect, timedOut = false)
  }

  private fun startBrainBlitzTimer() {
    brainBlitzLoopJob?.cancel()
    brainBlitzLoopJob =
      viewModelScope.launch {
        while (isActive) {
          delay(50L)
          val cur = _brainBlitz.value
          if (!cur.active || cur.finished) break
          val puzzle = cur.puzzle ?: continue
          val nextTime = cur.timeLeftSec - 0.05f
          if (nextTime <= 0f) {
            resolveBrainBlitzRound(cur, puzzle, isCorrect = false, timedOut = true)
          } else {
            _brainBlitz.value = cur.copy(timeLeftSec = nextTime)
          }
        }
      }
  }

  private fun resolveBrainBlitzRound(
    cur: BrainBlitzState,
    puzzle: BrainPuzzle,
    isCorrect: Boolean,
    timedOut: Boolean,
  ) {
    val nextStreak = if (isCorrect) cur.streak + 1 else 0
    val roundCoins = if (isCorrect) puzzle.bonusCoins + nextStreak * 3 else 0
    val roundScore = if (isCorrect) puzzle.bonusScore + nextStreak * 40 else 0
    val newScore = cur.score + roundScore
    val newCoins = cur.coinsEarned + roundCoins
    val newCorrect = cur.correctCount + (if (isCorrect) 1 else 0)

    soundEngine.playSfx(if (isCorrect) SoundEffect.BRAIN_CORRECT else SoundEffect.BRAIN_WRONG)

    if (cur.round >= cur.totalRounds) {
      brainBlitzLoopJob?.cancel()
      _brainBlitz.value =
        cur.copy(
          active = false,
          finished = true,
          score = newScore,
          coinsEarned = newCoins,
          streak = nextStreak,
          correctCount = newCorrect,
          puzzle = null,
          lastFeedback =
            if (isCorrect) "Final Blitz Solved! +$roundCoins Coins"
            else if (timedOut) "Time's Up!" else "Incorrect!",
        )
      viewModelScope.launch {
        saveRepository.updateProgress { p ->
          p.copy(
            coins = p.coins + newCoins,
            brainBlitzHighScore = maxOf(p.brainBlitzHighScore, newScore),
            totalHighScore = maxOf(p.totalHighScore, newScore),
          )
        }
      }
    } else {
      val nextRound = cur.round + 1
      val diff = ((nextRound + 1) / 2).coerceIn(1, 4)
      val nextPuzzle = BrainPuzzleEngine.generatePuzzle(diff)
      _brainBlitz.value =
        cur.copy(
          round = nextRound,
          score = newScore,
          coinsEarned = newCoins,
          streak = nextStreak,
          correctCount = newCorrect,
          puzzle = nextPuzzle,
          timeLeftSec = nextPuzzle.timeLimitSec,
          lastFeedback =
            if (isCorrect) "Correct! +$roundCoins Coins (Streak x$nextStreak)"
            else if (timedOut) "Time's Up! Streak Reset" else "Oops! Streak Reset",
        )
    }
  }

  // --- Shop, Themes, Characters & Settings ---

  fun selectOrBuyCharacter(characterId: String) {
    val spec = GameCatalog.getCharacter(characterId)
    val p = progress.value
    if (characterId in p.unlockedCharacterIds) {
      soundEngine.playSfx(SoundEffect.TAP)
      viewModelScope.launch {
        saveRepository.updateProgress { it.copy(selectedCharacterId = characterId) }
      }
    } else if (p.coins >= spec.cost) {
      soundEngine.playSfx(SoundEffect.POWER_UP)
      viewModelScope.launch {
        saveRepository.updateProgress { cur ->
          if (cur.coins >= spec.cost) {
            cur.copy(
              coins = cur.coins - spec.cost,
              unlockedCharacterIds = cur.unlockedCharacterIds + characterId,
              selectedCharacterId = characterId,
            )
          } else cur
        }
      }
      _bannerMessage.value = "Unlocked ${spec.name}!"
    } else {
      soundEngine.playSfx(SoundEffect.BRAIN_WRONG)
      _bannerMessage.value = "Need ${spec.cost - p.coins} more coins to unlock ${spec.name}."
    }
  }

  fun selectOrBuyTheme(themeId: String) {
    val spec = GameCatalog.getTheme(themeId)
    val p = progress.value
    if (themeId in p.unlockedThemeIds) {
      soundEngine.playSfx(SoundEffect.TAP)
      viewModelScope.launch {
        saveRepository.updateProgress { it.copy(selectedThemeId = themeId) }
      }
    } else if (p.coins >= spec.cost) {
      soundEngine.playSfx(SoundEffect.POWER_UP)
      viewModelScope.launch {
        saveRepository.updateProgress { cur ->
          if (cur.coins >= spec.cost) {
            cur.copy(
              coins = cur.coins - spec.cost,
              unlockedThemeIds = cur.unlockedThemeIds + themeId,
              selectedThemeId = themeId,
            )
          } else cur
        }
      }
      _bannerMessage.value = "Unlocked ${spec.name} Arena!"
    } else {
      soundEngine.playSfx(SoundEffect.BRAIN_WRONG)
      _bannerMessage.value = "Need ${spec.cost - p.coins} more coins for ${spec.name}."
    }
  }

  fun toggleSfxMute() {
    viewModelScope.launch {
      saveRepository.updateProgress { p -> p.copy(sfxMuted = !p.sfxMuted) }
    }
  }

  fun toggleBgmMute() {
    viewModelScope.launch {
      saveRepository.updateProgress { p -> p.copy(bgmMuted = !p.bgmMuted) }
    }
  }

  // --- Daily Rewards & Unity Ads ---

  fun claimDailyReward() {
    val today = epochDayProvider()
    val current = progress.value
    if (!current.canClaimDaily(today)) {
      _bannerMessage.value = "Today's reward is already claimed! Come back tomorrow."
      return
    }
    val dayIndex = current.nextDailyRewardIndex(today)
    val reward = GameCatalog.dailyRewards[dayIndex]
    val newStreak = dayIndex + 1
    soundEngine.playSfx(SoundEffect.LEVEL_COMPLETE)
    viewModelScope.launch {
      saveRepository.updateProgress { p ->
        if (!p.canClaimDaily(today)) p
        else {
          p.copy(
            coins = p.coins + reward.coins,
            dailyStreak = newStreak,
            lastDailyClaimEpochDay = today,
          )
        }
      }
    }
    _bannerMessage.value = "${reward.label} claimed! +${reward.coins} Coins!"
  }

  fun watchRewardedAd(activity: Activity) {
    soundEngine.playSfx(SoundEffect.TAP)
    adController.showRewardedAd(
      activity = activity,
      onRewardVerified = { coinsAwarded ->
        soundEngine.playSfx(SoundEffect.GEM)
        viewModelScope.launch {
          saveRepository.updateProgress { p ->
            p.copy(
              coins = p.coins + coinsAwarded,
              totalAdsWatched = p.totalAdsWatched + 1,
            )
          }
        }
        _bannerMessage.value = "Verified Ad Reward: +$coinsAwarded Coins added!"
      },
      onAdNotRewarded = { reason ->
        _bannerMessage.value = reason
      },
    )
  }

  fun retryRewardedAd() {
    soundEngine.playSfx(SoundEffect.TAP)
    adController.retry()
  }

  override fun onCleared() {
    super.onCleared()
    stopGameLoop()
    brainBlitzLoopJob?.cancel()
  }
}

class MainViewModelFactory(
  private val saveRepository: GameSaveRepository,
  private val adController: RewardedAdController,
  private val soundEngine: ArcadeSoundEngine,
) : ViewModelProvider.Factory {
  @Suppress("UNCHECKED_CAST")
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    return MainViewModel(saveRepository, adController, soundEngine) as T
  }
}
