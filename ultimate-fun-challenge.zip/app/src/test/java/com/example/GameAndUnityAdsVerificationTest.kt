package com.example

import android.app.Activity
import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.test.core.app.ApplicationProvider
import com.example.ads.LoadedRewardedAd
import com.example.ads.RewardedAdStatus
import com.example.ads.RewardedLoadCallback
import com.example.ads.RewardedShowCallbacks
import com.example.ads.UnityAdsConfig
import com.example.ads.UnityAdsManager
import com.example.ads.UnityAdsSdkBridge
import com.example.audio.ArcadeSoundEngine
import com.example.data.DataStoreGameSaveRepository
import com.example.data.GameCatalog
import com.example.data.InMemoryGameSaveRepository
import com.example.data.PlayerProgress
import com.example.game.BrainPuzzleEngine
import com.example.game.EntityKind
import com.example.game.RunMode
import com.example.game.RunPhase
import com.example.game.RunnerEngine
import com.example.game.TrackEntity
import com.unity3d.ads.InitializationConfiguration
import com.unity3d.ads.LoadConfiguration
import com.unity3d.ads.ShowConfiguration
import com.unity3d.ads.ShowFinishState
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GameAndUnityAdsVerificationTest {

  private class FakeLoadedAd : LoadedRewardedAd {
    var expiredHandler: (() -> Unit)? = null
    var showCallbacks: RewardedShowCallbacks? = null

    override fun setOnExpired(onExpired: () -> Unit) {
      expiredHandler = onExpired
    }

    override fun show(
      activity: Activity,
      configuration: ShowConfiguration,
      callbacks: RewardedShowCallbacks,
    ) {
      showCallbacks = callbacks
    }
  }

  private class FakeUnityAdsSdkBridge : UnityAdsSdkBridge {
    var initialized = false
    var initCalls = 0
    var lastInitConfig: InitializationConfiguration? = null
    var initCompleteCallback: ((Int?, String?) -> Unit)? = null

    var loadCalls = 0
    var lastLoadConfig: LoadConfiguration? = null
    var loadCallback: RewardedLoadCallback? = null
    var activeFakeAd: FakeLoadedAd? = null

    override fun isInitialized(): Boolean = initialized

    override fun initialize(
      config: InitializationConfiguration,
      onComplete: (errorCode: Int?, errorMessage: String?) -> Unit,
    ) {
      initCalls++
      lastInitConfig = config
      initCompleteCallback = onComplete
    }

    override fun load(configuration: LoadConfiguration, callback: RewardedLoadCallback) {
      loadCalls++
      lastLoadConfig = configuration
      loadCallback = callback
    }

    fun emitLoadedAd(): FakeLoadedAd {
      val ad = FakeLoadedAd()
      activeFakeAd = ad
      loadCallback?.onLoaded(ad)
      return ad
    }
  }

  @Test
  fun `catalog has at least 30 progressively challenging levels`() {
    assertTrue(GameCatalog.levels.size >= 30)
    assertEquals(35, GameCatalog.levels.size)
    val lvl1 = GameCatalog.getLevel(1)
    val lvl30 = GameCatalog.getLevel(30)
    assertTrue(lvl30.baseSpeed > lvl1.baseSpeed)
    assertTrue(lvl30.targetDistance > lvl1.targetDistance)
    assertTrue(lvl30.obstacleSpawnIntervalSec < lvl1.obstacleSpawnIntervalSec)
  }

  @Test
  fun `gameplay runner handles movement jump coin collection and level completion`() {
    val engine = RunnerEngine(Random(42))
    val level1 = GameCatalog.getLevel(1)
    val char1 = GameCatalog.getCharacter("nova_bot")
    var state = engine.createInitialState(RunMode.Campaign(level1), char1)

    state = engine.moveLeft(state).state
    assertEquals(0, state.targetLane)
    state = engine.moveRight(state).state
    state = engine.moveRight(state).state
    assertEquals(2, state.targetLane)

    state = engine.jump(state).state
    assertTrue(state.jumpVelocity > 0f)
    state = engine.step(state, 0.04f).state
    assertTrue(state.jumpHeight > 0f)

    state =
      state.copy(
        targetLane = 1,
        visualLane = 1f,
        entities = listOf(TrackEntity(id = 999L, kind = EntityKind.COIN, lane = 1, z = 0.08f)),
      )
    state = engine.step(state, 0.01f).state
    assertEquals(1, state.coinsCollected)

    state = state.copy(distance = level1.targetDistance + 5f, entities = emptyList())
    state = engine.step(state, 0.016f).state
    assertEquals(RunPhase.LEVEL_COMPLETE, state.phase)
    assertTrue(state.earnedStars in 1..3)
    assertTrue(state.completionBonusCoins > 0)
  }

  @Test
  fun `brain puzzle engine generates valid puzzles and runner awards brain gate bonuses`() {
    val puzzle = BrainPuzzleEngine.generatePuzzle(difficulty = 2, random = Random(123))
    assertEquals(4, puzzle.options.size)
    assertTrue(puzzle.correctIndex in 0..3)

    val engine = RunnerEngine(Random(7))
    val level1 = GameCatalog.getLevel(1)
    val char1 = GameCatalog.getCharacter("nova_bot")
    var state = engine.createInitialState(RunMode.Campaign(level1), char1)

    state =
      state.copy(
        entities =
          listOf(TrackEntity(id = 500L, kind = EntityKind.BRAIN_GATE_PORTAL, lane = 1, z = 0.08f))
      )
    state = engine.step(state, 0.016f).state
    assertEquals(RunPhase.BRAIN_GATE, state.phase)
    val activePuzzle = state.activeBrainPuzzle!!
    val prevCoins = state.coinsCollected

    state = engine.answerBrainPuzzle(state, activePuzzle.correctIndex).state
    assertEquals(RunPhase.RUNNING, state.phase)
    assertEquals(prevCoins + activePuzzle.bonusCoins, state.coinsCollected)
    assertTrue(state.hasShield)
  }

  @Test
  fun `save repository persists and restores coins unlocked levels high scores and settings`() = runTest {
    val file = File.createTempFile("ufc_save_test", ".preferences_pb")
    file.deleteOnExit()

    val job1 = Job()
    val scope1 = CoroutineScope(job1 + Dispatchers.IO)
    val ds1 = PreferenceDataStoreFactory.create(scope = scope1) { file }
    val repo1 = DataStoreGameSaveRepository(ds1, scope = scope1)
    repo1.ensureLoaded()
    repo1.updateProgress { p ->
      p.copy(
        coins = 450,
        highestUnlockedLevel = 7,
        levelHighScores = mapOf(1 to 1200, 6 to 3400),
        levelStars = mapOf(1 to 3, 6 to 2),
        endlessHighScore = 5800,
        totalHighScore = 5800,
        sfxMuted = true,
        bgmMuted = true,
        unlockedCharacterIds = setOf("nova_bot", "blaze_fox"),
        selectedCharacterId = "blaze_fox",
      )
    }
    scope1.cancel()
    job1.join()

    val job2 = Job()
    val scope2 = CoroutineScope(job2 + Dispatchers.IO)
    val ds2 = PreferenceDataStoreFactory.create(scope = scope2) { file }
    val repo2 = DataStoreGameSaveRepository(ds2, scope = scope2)
    repo2.ensureLoaded()
    val restored = repo2.progress.value
    scope2.cancel()
    job2.join()

    assertEquals(450, restored.coins)
    assertEquals(7, restored.highestUnlockedLevel)
    assertEquals(3400, restored.levelHighScores[6])
    assertEquals(3, restored.levelStars[1])
    assertEquals(5800, restored.endlessHighScore)
    assertTrue(restored.sfxMuted)
    assertTrue(restored.bgmMuted)
    assertTrue("blaze_fox" in restored.unlockedCharacterIds)
    assertEquals("blaze_fox", restored.selectedCharacterId)
  }

  @Test
  fun `unity ads initializes with required test identifiers and loads rewarded placement`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val bridge = FakeUnityAdsSdkBridge()
    val manager = UnityAdsManager(sdkBridge = bridge, connectivityChecker = { true })

    manager.initialize(context)

    assertEquals(1, bridge.initCalls)
    assertEquals("800449182", bridge.lastInitConfig?.gameId)
    assertEquals(true, bridge.lastInitConfig?.isTestModeEnabled)
    assertEquals(RewardedAdStatus.INITIALIZING, manager.uiState.value.status)

    bridge.initialized = true
    bridge.initCompleteCallback?.invoke(null, null)
    assertEquals(1, bridge.loadCalls)
    assertEquals("BP_Rewarded_Android", bridge.lastLoadConfig?.placementId)
    assertEquals(RewardedAdStatus.LOADING, manager.uiState.value.status)

    bridge.emitLoadedAd()
    assertEquals(RewardedAdStatus.READY, manager.uiState.value.status)
  }

  @Test
  fun `rewarded ad grants coins only on verified completion and blocks duplicate rewards`() {
    val activity = Robolectric.buildActivity(Activity::class.java).create().get()
    val bridge = FakeUnityAdsSdkBridge()
    val manager = UnityAdsManager(sdkBridge = bridge, connectivityChecker = { true })

    manager.initialize(activity.applicationContext)
    bridge.initialized = true
    bridge.initCompleteCallback?.invoke(null, null)
    val fakeAd = bridge.emitLoadedAd()

    val rewardsCount = AtomicInteger(0)
    val coinsTotal = AtomicInteger(0)
    val deniedReasons = mutableListOf<String>()

    manager.showRewardedAd(
      activity = activity,
      onRewardVerified = { coins ->
        rewardsCount.incrementAndGet()
        coinsTotal.addAndGet(coins)
      },
      onAdNotRewarded = { reason -> deniedReasons.add(reason) },
    )

    // Start & Click must NEVER grant coins
    fakeAd.showCallbacks?.onStarted()
    fakeAd.showCallbacks?.onClicked()
    assertEquals(0, rewardsCount.get())
    assertEquals(0, coinsTotal.get())

    // Verified reward callback grants coins once
    fakeAd.showCallbacks?.onRewarded()
    assertEquals(1, rewardsCount.get())
    assertEquals(UnityAdsConfig.REWARDED_COINS_AMOUNT, coinsTotal.get())

    // Subsequent onCompleted(COMPLETED) for the same show MUST NOT grant duplicate coins
    fakeAd.showCallbacks?.onCompleted(ShowFinishState.COMPLETED)
    assertEquals(1, rewardsCount.get())
    assertEquals(UnityAdsConfig.REWARDED_COINS_AMOUNT, coinsTotal.get())
  }

  @Test
  fun `skipped or failed ad never grants coins and preserves saved player progress`() = runTest {
    val activity = Robolectric.buildActivity(Activity::class.java).create().get()
    val bridge = FakeUnityAdsSdkBridge()
    var online = false
    val manager = UnityAdsManager(sdkBridge = bridge, connectivityChecker = { online })
    val saveRepo = InMemoryGameSaveRepository(PlayerProgress(coins = 333, highestUnlockedLevel = 12))
    val vm = MainViewModel(saveRepo, manager, ArcadeSoundEngine())

    // Offline init fails gracefully without resetting progress
    vm.initializeAds(activity.applicationContext)
    assertEquals(RewardedAdStatus.INIT_FAILED, manager.uiState.value.status)
    assertEquals(333, vm.progress.value.coins)
    assertEquals(12, vm.progress.value.highestUnlockedLevel)

    // Come online, retry, load, show, and SKIPPED -> 0 coins awarded
    online = true
    vm.retryRewardedAd()
    bridge.initialized = true
    bridge.initCompleteCallback?.invoke(null, null)
    val ad1 = bridge.emitLoadedAd()

    vm.watchRewardedAd(activity)
    ad1.showCallbacks?.onStarted()
    ad1.showCallbacks?.onCompleted(ShowFinishState.SKIPPED)
    assertEquals(333, vm.progress.value.coins)
    assertEquals(0, vm.progress.value.totalAdsWatched)
    assertFalse(manager.uiState.value.lastErrorMessage.isNullOrBlank())

    // Show failure also preserves progress
    val ad2 = bridge.emitLoadedAd()
    vm.watchRewardedAd(activity)
    ad2.showCallbacks?.onFailed(500, "Simulated playback error")
    assertEquals(333, vm.progress.value.coins)
    assertEquals(12, vm.progress.value.highestUnlockedLevel)
  }
}
