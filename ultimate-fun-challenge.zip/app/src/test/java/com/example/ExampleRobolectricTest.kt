package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `app name matches Ultimate Fun Challenge`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Ultimate Fun Challenge", appName)
  }

  @Test
  fun `game launches and navigates across core tabs`() {
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("play_next_level_button").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_levels").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("level_card_1").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_rewards").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("unity_ads_reward_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("watch_ad_button").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_shop").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("shop_character_nova_bot").assertIsDisplayed()
  }
}
